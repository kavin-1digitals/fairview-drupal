<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/services/sv-education.twig */
class __TwigTemplate_56bfe5c541cc72d28aaedd04ab8c6e9c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"sv-edu\" aria-labelledby=\"sv-edu-title\">
  <div class=\"sv-edu__inner\">
    <div class=\"sv-edu__left\">
      <h2 id=\"sv-edu-title\" class=\"sv-edu__title\">";
        // line 10
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_education_title", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_education_title"] ?? null), "")) : ("")), "html", null, true);
        yield "</h2>
      <p class=\"sv-edu__subtitle\">";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_education_subtitle", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_education_subtitle"] ?? null), "")) : ("")), "html", null, true);
        yield "</p>
      <a class=\"sv-edu__btn\" href=\"";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_education_button_url", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_education_button_url"] ?? null), "#")) : ("#")), "html", null, true);
        yield "\">";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_education_button_label", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_education_button_label"] ?? null), "")) : ("")), "html", null, true);
        yield "</a>
    </div>
    <div class=\"sv-edu__right\">
      ";
        // line 15
        if ((($tmp = ($context["sv_education_image"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 16
            yield "        <img class=\"sv-edu__img\" src=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_img_base", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_img_base"] ?? null), "")) : ("")), "html", null, true);
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["sv_education_image"] ?? null), "html", null, true);
            yield "\" width=\"640\" height=\"420\" alt=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Patient education resources"));
            yield "\" loading=\"lazy\" />
      ";
        }
        // line 18
        yield "    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["sv_education_title", "sv_education_subtitle", "sv_education_button_url", "sv_education_button_label", "sv_education_image", "sv_img_base"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/services/sv-education.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  76 => 18,  67 => 16,  65 => 15,  57 => 12,  53 => 11,  49 => 10,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/services/sv-education.twig", "/var/www/html/web/themes/custom/fairview/components/services/sv-education.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["if" => 15];
        static $filters = ["escape" => 10, "default" => 10, "t" => 16];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['if'],
                ['escape', 'default', 't'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
