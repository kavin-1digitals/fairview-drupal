<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/about-wwa/wwa-hero.twig */
class __TwigTemplate_a08bf7d20a068be5cae6f795e9a93e32 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"wwa-hero\" aria-labelledby=\"wwa-page-title\">
  <div class=\"wwa-hero__text\">
    <div class=\"wwa-hero__text-inner\">
      <h1 id=\"wwa-page-title\" class=\"wwa-hero__title\">";
        // line 10
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("What Makes Fairview Different?"));
        yield "</h1>
      <p class=\"wwa-hero__lead\">";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("A health service that heals from the heart"));
        yield "</p>
      <div class=\"wwa-hero__body\">
        <p>";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview Health Services is Minnesota’s choice for healthcare. We’re an industry-leading, award-winning, nonprofit offering a full network of healthcare services. Our broad network is designed to be ready for our patients’ every need, while delivering quality care with compassion."));
        yield "</p>
        <p>";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Our care portfolio includes community hospitals, academic hospitals, primary and specialty care clinics, senior facilities, facilitated living centers, rehabilitation centers, home health care services, counseling, pharmacies and benefit management services."));
        yield "</p>
        <p>";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("We’re built on a tradition of compassionate care. This is our home, and our patients are our neighbors. We’re here to heal, we’re here for you."));
        yield "</p>
      </div>
    </div>
  </div>
  <div class=\"wwa-hero__media\">
    <img class=\"wwa-hero__img\"
         src=\"";
        // line 21
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("wwa_img_base", $context)) ? (Twig\Extension\CoreExtension::default(($context["wwa_img_base"] ?? null), "")) : ("")), "html", null, true);
        yield "who-we-are-cover.avif\"
         width=\"960\"
         height=\"720\"
         alt=\"\"
         loading=\"eager\" />
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["wwa_img_base"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/about-wwa/wwa-hero.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  75 => 21,  66 => 15,  62 => 14,  58 => 13,  53 => 11,  49 => 10,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/about-wwa/wwa-hero.twig", "/var/www/html/web/themes/custom/fairview/components/about-wwa/wwa-hero.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["t" => 10, "escape" => 21, "default" => 21];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['t', 'escape', 'default'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
