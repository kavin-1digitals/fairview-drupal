<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/provider-search/ps-alert.twig */
class __TwigTemplate_34a14864dfa04dfc9ef54ea2c355be6d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        $context["_paras"] = Twig\Extension\CoreExtension::split($this->env->getCharset(), Twig\Extension\CoreExtension::trim(((array_key_exists("alert_message", $context)) ? (Twig\Extension\CoreExtension::default(($context["alert_message"] ?? null), "")) : (""))), "

");
        // line 5
        yield "<div class=\"ps-alerts\" data-ps-alerts>
  <div class=\"ps-alert\" data-ps-alert=\"combined\" role=\"region\" aria-label=\"";
        // line 6
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Important information"));
        yield "\">
    <div class=\"ps-alert__body\">
      ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["_paras"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["para"]) {
            // line 9
            yield "        ";
            if ((Twig\Extension\CoreExtension::trim($context["para"]) != "")) {
                // line 10
                yield "          <p class=\"ps-alert__p\">";
                yield Twig\Extension\CoreExtension::nl2br($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Twig\Extension\CoreExtension::trim($context["para"]), "html", null, true));
                yield "</p>
        ";
            }
            // line 12
            yield "      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['para'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        yield "    </div>
    <button type=\"button\" class=\"ps-alert__close\" data-ps-alert-dismiss aria-label=\"";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Dismiss alert"));
        yield "\">
      <svg class=\"ps-alert__close-icon\" width=\"18\" height=\"18\" viewBox=\"0 0 18 18\" fill=\"none\" aria-hidden=\"true\" focusable=\"false\">
        <path d=\"M4 4l10 10M14 4L4 14\" stroke=\"currentColor\" stroke-width=\"1.75\" stroke-linecap=\"round\"/>
      </svg>
    </button>
  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["alert_message"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/provider-search/ps-alert.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  78 => 14,  75 => 13,  69 => 12,  63 => 10,  60 => 9,  56 => 8,  51 => 6,  48 => 5,  44 => 4,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/provider-search/ps-alert.twig", "/var/www/html/web/themes/custom/fairview/components/provider-search/ps-alert.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 4, "for" => 8, "if" => 9];
        static $filters = ["split" => 4, "trim" => 4, "default" => 4, "t" => 6, "nl2br" => 10, "escape" => 10];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'for', 'if'],
                ['split', 'trim', 'default', 't', 'nl2br', 'escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
