<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:section */
class __TwigTemplate_631845bf73b0d449127028aef0f1184b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'background_media_block' => [$this, 'block_background_media_block'],
            'header_slot' => [$this, 'block_header_slot'],
            'main_slot' => [$this, 'block_main_slot'],
            'footer_slot' => [$this, 'block_footer_slot'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--section"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:section"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:section"));
        // line 2
        $context["has_background_image"] = ( !Twig\Extension\CoreExtension::testEmpty(($context["background_media"] ?? null)) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["background_media"] ?? null), "src", [], "any", false, false, true, 2)));
        // line 4
        $context["has_background_image_variant"] = (((($tmp = ($context["has_background_image"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 5
        $context["is_restricted"] = (((($tmp = ($context["restrict_width"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 6
        $context["is_reverse"] = (((($tmp = ($context["reverse_mobile"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 7
        yield "
";
        // line 8
        $context["section"] = Twig\Extra\Html\HtmlExtension::htmlCva(["@container relative mx-auto flex flex-col items-stretch"], ["width" => ["100%" => "lg:max-w-full", "90%" => "lg:max-w-9/10", "80%" => "lg:max-w-8/10", "70%" => "lg:max-w-7/10", "60%" => "lg:max-w-6/10", "50%" => "lg:max-w-1/2"], "marginBlockStart" => ["-48" => "-md:mt-10 -xl:mt-12 -mt-8", "-20" => "-mt-5", "0" => "mt-0", "8" => "mt-2", "20" => "mt-5", "32" => "mt-6 md:mt-7 xl:mt-8", "48" => "mt-8 md:mt-10 xl:mt-12", "64" => "mt-10 md:mt-13 xl:mt-16", "96" => "mt-16 md:mt-20 xl:mt-24", "128" => "mt-20 md:mt-24 xl:mt-32"], "marginBlockEnd" => ["0" => "mb-0", "8" => "mb-2", "20" => "mb-5", "32" => "mb-6 md:mb-7 xl:mb-8", "48" => "mb-8 md:mb-10 xl:mb-12", "64" => "mb-10 md:mb-13 xl:mb-16", "96" => "mb-16 md:mb-20 xl:mb-24", "128" => "mb-20 md:mb-24 xl:mb-32"], "paddingBlockStart" => ["0" => "pt-0", "16" => "pt-4", "32" => "pt-6", "64" => "pt-10 md:pt-12 xl:pt-16"], "paddingBlockEnd" => ["0" => "pb-0", "16" => "pb-4", "32" => "pb-6", "64" => "pb-10 md:pb-13 xl:pb-16"], "backgroundColor" => ["primary" => "text-primary-foreground", "secondary" => "text-secondary-foreground", "accent" => "text-accent-foreground", "muted" => "text-muted-foreground", "white" => "text-foreground", "noColor" => "text-foreground"], "restrictedWidth" => ["no" => "cq-full"]]);
        // line 68
        yield "
";
        // line 69
        $context["section_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 70
($context["section"] ?? null), "apply", [["marginBlockStart" =>         // line 71
($context["margin_block_start"] ?? null), "marginBlockEnd" =>         // line 72
($context["margin_block_end"] ?? null), "paddingBlockStart" =>         // line 73
($context["padding_block_start"] ?? null), "paddingBlockEnd" =>         // line 74
($context["padding_block_end"] ?? null), "backgroundColor" => ((        // line 75
array_key_exists("background_color", $context)) ? (Twig\Extension\CoreExtension::default(($context["background_color"] ?? null), "noColor")) : ("noColor")), "restrictedWidth" =>         // line 76
($context["is_restricted"] ?? null)]], "method", false, false, true, 70);
        // line 79
        yield "
";
        // line 80
        $context["section_content"] = CoreExtension::getAttribute($this->env, $this->source,         // line 81
($context["section"] ?? null), "apply", [["width" => ((        // line 82
array_key_exists("width", $context)) ? (Twig\Extension\CoreExtension::default(($context["width"] ?? null), "100%")) : ("100%"))]], "method", false, false, true, 81);
        // line 85
        yield "
";
        // line 86
        $context["background"] = Twig\Extra\Html\HtmlExtension::htmlCva(["absolute", "inset-0", "z-[-1]"], ["backgroundColor" => ["muted" => "bg-muted", "white" => "bg-white", "noColor" => "bg-none"], "backgroundImage" => ["yes" => "opacity-50", "no" => ""], "restrictedWidth" => ["yes" => "rounded-md"]], [["backgroundColor" => "primary", "backgroundImage" => "no", "class" => "bg-primary"], ["backgroundColor" => "primary", "backgroundImage" => "yes", "class" => "bg-primary-dark"], ["backgroundColor" => "secondary", "backgroundImage" => "no", "class" => "bg-secondary"], ["backgroundColor" => "secondary", "backgroundImage" => "yes", "class" => "bg-secondary-dark"], ["backgroundColor" => "accent", "backgroundImage" => "no", "class" => "bg-accent"], ["backgroundColor" => "accent", "backgroundImage" => "yes", "class" => "bg-accent-dark"]]);
        // line 137
        yield "
";
        // line 138
        $context["background_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 139
($context["background"] ?? null), "apply", [["backgroundColor" => ((        // line 140
array_key_exists("background_color", $context)) ? (Twig\Extension\CoreExtension::default(($context["background_color"] ?? null), "noColor")) : ("noColor")), "backgroundImage" =>         // line 141
($context["has_background_image_variant"] ?? null), "restrictedWidth" =>         // line 142
($context["is_restricted"] ?? null)]], "method", false, false, true, 139);
        // line 145
        yield "
";
        // line 146
        $context["section_image"] = Twig\Extra\Html\HtmlExtension::htmlCva(["h-full w-full object-cover"], ["overlay" => ["noColor" => "opacity-70"], "restrictedWidth" => ["yes" => "rounded-md"]], [["backgroundColor" => ["primary", "secondary", "accent", "muted", "white"], "class" => "grayscale-75"]]);
        // line 165
        yield "
";
        // line 166
        $context["grid"] = Twig\Extra\Html\HtmlExtension::htmlCva(["grid w-full min-w-0", "gap-4 @sm:gap-6 @3xl:gap-8", "[&>*]:w-full [&>*]:min-w-0", "[&_.view-content]:grid [&_.view-content]:w-full [&_.view-content]:min-w-0", "[&_.view-content]:gap-4 [&_.view-content]:md:gap-6 [&_.view-content]:xl:gap-8"], ["columns" => ["1 column" => "grid-cols-1", "2 columns" => "md:grid-cols-2", "2 columns 75-25" => "md:grid-cols-[minmax(0,3fr)_minmax(0,1fr)]", "2 columns 25-75" => "md:grid-cols-[minmax(0,1fr)_minmax(0,3fr)]", "2 columns 67-33" => "md:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]", "2 columns 33-67" => "md:grid-cols-[minmax(0,1fr)_minmax(0,2fr)]", "3 columns" => "md:grid-cols-3", "4 columns" => "sm:grid-cols-2 lg:grid-cols-4", "5 columns" => "sm:grid-cols-2 lg:grid-cols-5", "6 columns" => "sm:grid-cols-3 lg:grid-cols-6"], "mobileColumns" => ["1" => "", "2" => "grid-cols-2", "3" => "grid-cols-3"], "viewsColumns" => ["1 column" => "", "2 columns" => "[&_.view-content]:md:grid-cols-2", "3 columns" => "[&_.view-content]:md:grid-cols-3", "4 columns" => "[&_.view-content]:sm:grid-cols-2 [&_.view-content]:lg:grid-cols-4", "5 columns" => "[&_.view-content]:sm:grid-cols-2 [&_.view-content]:lg:grid-cols-5", "6 columns" => "[&_.view-content]:sm:grid-cols-3 [&_.view-content]:lg:grid-cols-6"], "reverseMobile" => ["yes" => "[&>*:first-child]:order-1 md:[&>*:first-child]:-order-1 [&>*:last-child]:-order-1 md:[&>*:last-child]:order-1"]], [["columns" => ["4 columns"], "mobileColumns" => ["2"], "class" => "sm:grid-cols-4"]]);
        // line 214
        yield "
";
        // line 215
        $context["grid_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 216
($context["grid"] ?? null), "apply", [["columns" => ((        // line 217
array_key_exists("columns", $context)) ? (Twig\Extension\CoreExtension::default(($context["columns"] ?? null), "100")) : ("100")), "mobileColumns" => ((        // line 218
array_key_exists("mobile_columns", $context)) ? (Twig\Extension\CoreExtension::default(($context["mobile_columns"] ?? null), "1")) : ("1")), "viewsColumns" => ((        // line 219
array_key_exists("views_columns", $context)) ? (Twig\Extension\CoreExtension::default(($context["views_columns"] ?? null), "100")) : ("100")), "reverseMobile" =>         // line 220
($context["is_reverse"] ?? null)]], "method", false, false, true, 216);
        // line 223
        yield "
<section class=\"";
        // line 224
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["section_classes"] ?? null), "html", null, true);
        yield "\">
  ";
        // line 226
        yield "  ";
        if (( !Twig\Extension\CoreExtension::testEmpty(($context["background_media"] ?? null)) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["background_media"] ?? null), "src", [], "any", false, false, true, 226)))) {
            // line 227
            yield "    ";
            yield from $this->unwrap()->yieldBlock('background_media_block', $context, $blocks);
            // line 241
            yield "  ";
        }
        // line 242
        yield "
  ";
        // line 244
        yield "  ";
        if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["background_color"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 245
            yield "    <div class=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["background_classes"] ?? null), "html", null, true);
            yield "\"></div>
  ";
        }
        // line 247
        yield "
  <div class=\"container [&_.cq-full]:mx-0 [&_.cq-full]:w-full\">
    <div class=\"";
        // line 249
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["section_content"] ?? null), "html", null, true);
        yield "\">
      ";
        // line 250
        if ((($tmp = ($context["section_header"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 251
            yield "        ";
            $context["header_content"] = ('' === $tmp = implode('', iterator_to_array((function () use (&$context, $macros, $blocks) {
                // line 252
                yield "          ";
                yield from $this->unwrap()->yieldBlock('header_slot', $context, $blocks);
                // line 255
                yield "        ";
                yield from [];
            })(), false))) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 256
            yield "        ";
            if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(($context["header_content"] ?? null)))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 257
                yield "          <header class=\"mb-6 md:mb-8 xl:mb-10\">
            ";
                // line 258
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["header_content"] ?? null), "html", null, true);
                yield "
          </header>
        ";
            }
            // line 261
            yield "      ";
        }
        // line 262
        yield "
      <div class=\"";
        // line 263
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["grid_classes"] ?? null), "html", null, true);
        yield "\">
        ";
        // line 264
        yield from $this->unwrap()->yieldBlock('main_slot', $context, $blocks);
        // line 267
        yield "      </div>

      ";
        // line 269
        if ((($tmp = ($context["section_footer"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 270
            yield "        ";
            $context["footer_content"] = ('' === $tmp = implode('', iterator_to_array((function () use (&$context, $macros, $blocks) {
                // line 271
                yield "          ";
                yield from $this->unwrap()->yieldBlock('footer_slot', $context, $blocks);
                // line 274
                yield "        ";
                yield from [];
            })(), false))) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 275
            yield "        ";
            if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(Twig\Extension\CoreExtension::trim(($context["footer_content"] ?? null)))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 276
                yield "          <footer class=\"mt-6 md:mt-8 xl:mt-10\">
            ";
                // line 277
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["footer_content"] ?? null), "html", null, true);
                yield "
          </footer>
        ";
            }
            // line 280
            yield "      ";
        }
        // line 281
        yield "    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["background_media", "restrict_width", "reverse_mobile", "margin_block_start", "margin_block_end", "padding_block_start", "padding_block_end", "background_color", "width", "columns", "mobile_columns", "views_columns", "section_header", "section_footer"]);        yield from [];
    }

    // line 227
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_background_media_block(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 228
        yield "      <div class=\"absolute inset-0 z-[-1]\">
        ";
        // line 229
        try {
            $_v0 = $this->load("canvas:image", 229);
        } catch (LoaderError $e) {
            // ignore missing template
            $_v0 = null;
        }
        if ($_v0) {
            yield from $_v0->unwrap()->yield(CoreExtension::toArray(["src" => CoreExtension::getAttribute($this->env, $this->source,             // line 230
($context["background_media"] ?? null), "src", [], "any", false, false, true, 230), "alt" => CoreExtension::getAttribute($this->env, $this->source,             // line 231
($context["background_media"] ?? null), "alt", [], "any", false, false, true, 231), "class" => CoreExtension::getAttribute($this->env, $this->source,             // line 232
($context["section_image"] ?? null), "apply", [["restrictedWidth" =>             // line 233
($context["is_restricted"] ?? null), "backgroundColor" => ((            // line 234
array_key_exists("background_color", $context)) ? (Twig\Extension\CoreExtension::default(($context["background_color"] ?? null), "noColor")) : ("noColor"))]], "method", false, false, true, 232), "width" => CoreExtension::getAttribute($this->env, $this->source,             // line 236
($context["background_media"] ?? null), "width", [], "any", false, false, true, 236), "height" => CoreExtension::getAttribute($this->env, $this->source,             // line 237
($context["background_media"] ?? null), "height", [], "any", false, false, true, 237)]));
        }
        // line 239
        yield "      </div>
    ";
        yield from [];
    }

    // line 252
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header_slot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 253
        yield "
          ";
        yield from [];
    }

    // line 264
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main_slot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 265
        yield "
        ";
        yield from [];
    }

    // line 271
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_slot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 272
        yield "
          ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:section";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  296 => 272,  289 => 271,  283 => 265,  276 => 264,  270 => 253,  263 => 252,  257 => 239,  254 => 237,  253 => 236,  252 => 234,  251 => 233,  250 => 232,  249 => 231,  248 => 230,  240 => 229,  237 => 228,  230 => 227,  221 => 281,  218 => 280,  212 => 277,  209 => 276,  206 => 275,  202 => 274,  199 => 271,  196 => 270,  194 => 269,  190 => 267,  188 => 264,  184 => 263,  181 => 262,  178 => 261,  172 => 258,  169 => 257,  166 => 256,  162 => 255,  159 => 252,  156 => 251,  154 => 250,  150 => 249,  146 => 247,  140 => 245,  137 => 244,  134 => 242,  131 => 241,  128 => 227,  125 => 226,  121 => 224,  118 => 223,  116 => 220,  115 => 219,  114 => 218,  113 => 217,  112 => 216,  111 => 215,  108 => 214,  106 => 166,  103 => 165,  101 => 146,  98 => 145,  96 => 142,  95 => 141,  94 => 140,  93 => 139,  92 => 138,  89 => 137,  87 => 86,  84 => 85,  82 => 82,  81 => 81,  80 => 80,  77 => 79,  75 => 76,  74 => 75,  73 => 74,  72 => 73,  71 => 72,  70 => 71,  69 => 70,  68 => 69,  65 => 68,  63 => 8,  60 => 7,  58 => 6,  56 => 5,  54 => 4,  52 => 2,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:section", "themes/contrib/haven_theme/components/section/section.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 2, "if" => 226, "block" => 227, "include" => 229];
        static $filters = ["default" => 75, "escape" => 224, "trim" => 256];
        static $functions = ["html_cva" => 9];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['default', 'escape', 'trim'],
                ['html_cva'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
