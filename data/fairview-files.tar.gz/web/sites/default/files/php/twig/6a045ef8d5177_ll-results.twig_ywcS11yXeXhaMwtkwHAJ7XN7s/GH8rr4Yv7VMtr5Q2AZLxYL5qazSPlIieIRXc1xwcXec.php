<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/location-list/ll-results.twig */
class __TwigTemplate_5645459407d69ff452924adee28510e7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<div class=\"ll-main\">
  <header class=\"ll-main__head\">
    <p class=\"ll-main__summary\">";
        // line 6
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("ll_results_summary", $context)) ? (Twig\Extension\CoreExtension::default(($context["ll_results_summary"] ?? null), "")) : ("")), "html", null, true);
        yield "</p>
  </header>

  <div class=\"ll-active\" data-ll-active hidden>
    <div class=\"ll-active__row\">
      <span class=\"ll-active__label\">";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Active Filters:"));
        yield "</span>
      <div class=\"ll-active__chips\" data-ll-chips></div>
      <button type=\"button\" class=\"ll-active__clear\" data-ll-clear-all>";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Clear all"));
        yield "</button>
    </div>
  </div>

  <ul class=\"ll-cards\" role=\"list\">
    ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("ll_locations", $context)) ? (Twig\Extension\CoreExtension::default(($context["ll_locations"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["loc"]) {
            // line 19
            yield "      <li class=\"ll-card\">
        <div class=\"ll-card__media ll-card__media--ph";
            // line 20
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "ph", [], "any", true, true, true, 20)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "ph", [], "any", false, false, true, 20), 0)) : (0)), "html", null, true);
            yield "\">
          <span class=\"visually-hidden\">";
            // line 21
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Location photo placeholder"));
            yield "</span>
        </div>
        <div class=\"ll-card__status ";
            // line 23
            if (CoreExtension::inFilter("Open Now", CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "status", [], "any", false, false, true, 23))) {
                yield "ll-card__status--open";
            }
            yield "\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "status", [], "any", false, false, true, 23), "html", null, true);
            yield "</div>
        <div class=\"ll-card__body\">
          <p class=\"ll-card__type\">";
            // line 25
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "location_type", [], "any", false, false, true, 25), "html", null, true);
            yield "</p>
          <h3 class=\"ll-card__title\">";
            // line 26
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "title", [], "any", false, false, true, 26), "html", null, true);
            yield "</h3>
          <p class=\"ll-card__subtitle\">";
            // line 27
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "location", [], "any", false, false, true, 27), "html", null, true);
            yield "</p>
          <p class=\"ll-card__contact\">
            <a href=\"#\" class=\"ll-card__link\">";
            // line 29
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("View Contact Details"));
            yield "</a>
          </p>
          <p class=\"ll-card__addr\">";
            // line 31
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "address", [], "any", false, false, true, 31), "html", null, true);
            yield "</p>
          ";
            // line 32
            if ((is_iterable(CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "amenities", [], "any", false, false, true, 32)) && (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "amenities", [], "any", false, false, true, 32)) > 0))) {
                // line 33
                yield "            <ul class=\"ll-card__amenities\" aria-label=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Amenities"));
                yield "\">
              ";
                // line 34
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["loc"], "amenities", [], "any", false, false, true, 34));
                foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
                    // line 35
                    yield "                <li class=\"ll-card__amenity\">";
                    if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                        if (\array_key_exists("canvas_slot_ids", $context) && \in_array("a", $context["canvas_slot_ids"], TRUE)) {
                            yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "a");
                        } else {
                            yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "a");
                        }
                    }
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $context["a"], "html", null, true);
                    if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                        if (\array_key_exists("canvas_slot_ids", $context) && \in_array("a", $context["canvas_slot_ids"], TRUE)) {
                            yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "a");
                        } else {
                            yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "a");
                        }
                    }
                    yield "</li>
              ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['a'], $context['_parent']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 37
                yield "            </ul>
          ";
            }
            // line 39
            yield "          <p class=\"ll-card__cta\">
            <a href=\"#\" class=\"ll-card__btn\">";
            // line 40
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("View Location Details"));
            yield "</a>
          </p>
        </div>
      </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['loc'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 45
        yield "  </ul>

  <nav class=\"ll-pagination\" aria-label=\"";
        // line 47
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Pagination"));
        yield "\">
    <a href=\"#\" class=\"ll-pagination__nav\" aria-disabled=\"true\">";
        // line 48
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Previous"));
        yield "</a>
    <ol class=\"ll-pagination__list\">
      <li><a href=\"#\" class=\"ll-pagination__num is-current\" aria-current=\"page\">1</a></li>
      <li><a href=\"#\" class=\"ll-pagination__num\">2</a></li>
      <li><a href=\"#\" class=\"ll-pagination__num\">3</a></li>
      <li><span class=\"ll-pagination__ellipsis\">&hellip;</span></li>
      <li><a href=\"#\" class=\"ll-pagination__num\">5</a></li>
    </ol>
    <a href=\"#\" class=\"ll-pagination__nav\">";
        // line 56
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Next"));
        yield "</a>
  </nav>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["ll_results_summary", "ll_locations"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/location-list/ll-results.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  187 => 56,  176 => 48,  172 => 47,  168 => 45,  157 => 40,  154 => 39,  150 => 37,  127 => 35,  123 => 34,  118 => 33,  116 => 32,  112 => 31,  107 => 29,  102 => 27,  98 => 26,  94 => 25,  85 => 23,  80 => 21,  76 => 20,  73 => 19,  69 => 18,  61 => 13,  56 => 11,  48 => 6,  44 => 4,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/location-list/ll-results.twig", "/var/www/html/web/themes/custom/fairview/components/location-list/ll-results.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 18, "if" => 23];
        static $filters = ["escape" => 6, "default" => 6, "t" => 11, "length" => 32];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if'],
                ['escape', 'default', 't', 'length'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
