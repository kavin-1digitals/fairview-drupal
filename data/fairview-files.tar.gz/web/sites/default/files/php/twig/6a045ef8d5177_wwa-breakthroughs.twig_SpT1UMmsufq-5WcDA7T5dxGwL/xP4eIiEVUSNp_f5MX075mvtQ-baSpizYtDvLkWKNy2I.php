<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/about-wwa/wwa-breakthroughs.twig */
class __TwigTemplate_c24b48a04229a6ae4aa2075a6900ea68 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"wwa-band wwa-band--muted\" aria-labelledby=\"wwa-breakthroughs-title\">
  <div class=\"wwa-band__inner\">
    <h2 id=\"wwa-breakthroughs-title\" class=\"wwa-band__title\">";
        // line 9
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("We Build Towards Breakthroughs"));
        yield "</h2>
    <div class=\"wwa-cols wwa-cols--3\">
      <div class=\"wwa-col\">
        <h3 class=\"wwa-col__title\">";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Defining Discoveries"));
        yield "</h3>
        <p class=\"wwa-col__desc\">";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("As good as our care is, we need to be at the forefront of every advancement. This is why we devote so many resources into advancements in patient care, and have so much pride in our results."));
        yield "</p>
      </div>
      <div class=\"wwa-col\">
        <h3 class=\"wwa-col__title\">";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Educating New Generations"));
        yield "</h3>
        <p class=\"wwa-col__desc\">";
        // line 17
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Good doctors come from the best teachers. Our doctors work in collaboration with the Academic Health Center to educate student physicians."));
        yield "</p>
      </div>
      <div class=\"wwa-col\">
        <h3 class=\"wwa-col__title\">";
        // line 20
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Promoting Breakthrough Therapies"));
        yield "</h3>
        <p class=\"wwa-col__desc\">";
        // line 21
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("When new treatments are discovered, we want those techniques and technologies in the hands of our physicians immediately. A breakthrough only happens as fast its implementation."));
        yield "</p>
      </div>
    </div>
  </div>
</section>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/about-wwa/wwa-breakthroughs.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  78 => 21,  74 => 20,  68 => 17,  64 => 16,  58 => 13,  54 => 12,  48 => 9,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/about-wwa/wwa-breakthroughs.twig", "/var/www/html/web/themes/custom/fairview/components/about-wwa/wwa-breakthroughs.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["t" => 9];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['t'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
