<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/get-care/gc-slider.twig */
class __TwigTemplate_9ae0ce5533c54cabbf0871cce4781e0c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"gc-slider\" data-gc-slider aria-labelledby=\"gc-slider-heading\">
  <div class=\"gc-slider__head\">
    <h2 id=\"gc-slider-heading\" class=\"gc-slider__heading\">";
        // line 9
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("More ways to get care"));
        yield "</h2>
    <div class=\"gc-slider__nav\">
      <button type=\"button\" class=\"gc-slider__btn gc-slider__btn--prev\" data-gc-prev aria-label=\"";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Previous"));
        yield "\">
        <span aria-hidden=\"true\">‹</span>
      </button>
      <button type=\"button\" class=\"gc-slider__btn gc-slider__btn--next\" data-gc-next aria-label=\"";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Next"));
        yield "\">
        <span aria-hidden=\"true\">›</span>
      </button>
    </div>
  </div>
  <div class=\"gc-slider__viewport\">
    <div class=\"gc-slider__track\" data-gc-track>
      ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("gc_slider_cards", $context)) ? (Twig\Extension\CoreExtension::default(($context["gc_slider_cards"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["slide"]) {
            // line 22
            yield "        <article class=\"gc-slide\">
          <div class=\"gc-slide__media\" aria-hidden=\"true\">
            <div class=\"gc-slide__placeholder\"></div>
          </div>
          <div class=\"gc-slide__body\">
            <h3 class=\"gc-slide__title\">";
            // line 27
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["slide"], "title", [], "any", false, false, true, 27), "html", null, true);
            yield "</h3>
            <p class=\"gc-slide__desc\">";
            // line 28
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["slide"], "description", [], "any", false, false, true, 28), "html", null, true);
            yield "</p>
            <a class=\"gc-slide__btn\" href=\"";
            // line 29
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((CoreExtension::getAttribute($this->env, $this->source, $context["slide"], "url", [], "any", true, true, true, 29)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["slide"], "url", [], "any", false, false, true, 29), "#")) : ("#")), "html", null, true);
            yield "\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["slide"], "button", [], "any", false, false, true, 29), "html", null, true);
            yield "</a>
          </div>
        </article>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['slide'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        yield "    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["gc_slider_cards"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/get-care/gc-slider.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  100 => 33,  88 => 29,  84 => 28,  80 => 27,  73 => 22,  69 => 21,  59 => 14,  53 => 11,  48 => 9,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/get-care/gc-slider.twig", "/var/www/html/web/themes/custom/fairview/components/get-care/gc-slider.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 21];
        static $filters = ["t" => 9, "default" => 21, "escape" => 27];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['t', 'default', 'escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
