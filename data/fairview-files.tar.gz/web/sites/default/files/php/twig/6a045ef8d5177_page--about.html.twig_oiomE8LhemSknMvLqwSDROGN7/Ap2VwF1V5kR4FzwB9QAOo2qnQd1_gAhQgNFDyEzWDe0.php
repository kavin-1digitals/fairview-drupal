<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/fairview/templates/layout/page--about.html.twig */
class __TwigTemplate_1fa29edaa04fcf7aefb184e51c00bc94 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_body' => [$this, 'block_page_body'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@fairview/templates/layout/page.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@fairview/templates/layout/page.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<div class=\"about-page\" data-about-page>
  ";
        // line 5
        yield from $this->load("@fairview/components/about-wwa/wwa-hero.twig", 5)->unwrap()->yield($context);
        // line 6
        yield "  ";
        yield from $this->load("@fairview/components/about-wwa/wwa-values.twig", 6)->unwrap()->yield($context);
        // line 7
        yield "  ";
        yield from $this->load("@fairview/components/about-wwa/wwa-feature-cards.twig", 7)->unwrap()->yield($context);
        // line 8
        yield "  ";
        yield from $this->load("@fairview/components/about-wwa/wwa-breakthroughs.twig", 8)->unwrap()->yield($context);
        // line 9
        yield "  ";
        yield from $this->load("@fairview/components/about-wwa/wwa-impact.twig", 9)->unwrap()->yield($context);
        // line 10
        yield "  ";
        yield from $this->load("@fairview/components/about-wwa/wwa-community.twig", 10)->unwrap()->yield($context);
        // line 11
        yield "  ";
        yield from $this->load("@fairview/components/about-wwa/wwa-transparency.twig", 11)->unwrap()->yield($context);
        // line 12
        yield "</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/fairview/templates/layout/page--about.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  83 => 12,  80 => 11,  77 => 10,  74 => 9,  71 => 8,  68 => 7,  65 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/fairview/templates/layout/page--about.html.twig", "/var/www/html/web/themes/custom/fairview/templates/layout/page--about.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["extends" => 1, "include" => 5];
        static $filters = [];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['extends', 'include'],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
