<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:group */
class __TwigTemplate_b71e9d1cd652796f9f2b5674f2e80078 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'group_slot' => [$this, 'block_group_slot'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--group"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:group"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:group"));
        $context["is_stretched"] = (((($tmp = ($context["stretch"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 2
        yield "
";
        // line 3
        $context["group"] = Twig\Extra\Html\HtmlExtension::htmlCva(["flex bg-none"], ["flexDirection" => ["column" => "flex-col", "row" => "flex-row", "column-reverse" => "flex-col-reverse", "row-reverse" => "flex-row-reverse"], "groupAlign" => ["start" => "items-start justify-start", "center" => "items-center justify-center", "end" => "items-end justify-end"], "flexAlign" => ["start" => "self-start", "center" => "self-center", "end" => "self-end"], "flexGap" => ["sm" => "gap-2", "md" => "gap-4", "lg" => "gap-8", "xl" => "gap-16"], "radius" => ["sm" => "rounded-sm", "md" => "rounded-md", "lg" => "rounded-lg", "xl" => "rounded-xl"], "padding" => ["sm" => "p-4", "md" => "p-8", "lg" => "p-16", "xl" => "p-32"], "background" => ["primary" => "bg-primary", "secondary" => "bg-secondary", "accent" => "bg-accent", "white" => "bg-white", "muted" => "bg-muted"], "stretch" => ["yes" => "h-full w-full"]]);
        // line 54
        yield "
";
        // line 55
        $context["group_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 56
($context["group"] ?? null), "apply", [["flexDirection" =>         // line 57
($context["flex_direction"] ?? null), "groupAlign" => ((        // line 58
array_key_exists("items_align", $context)) ? (Twig\Extension\CoreExtension::default(($context["items_align"] ?? null), "start")) : ("start")), "flexAlign" => ((        // line 59
array_key_exists("flex_align", $context)) ? (Twig\Extension\CoreExtension::default(($context["flex_align"] ?? null), "center")) : ("center")), "flexGap" =>         // line 60
($context["flex_gap"] ?? null), "radius" =>         // line 61
($context["radius"] ?? null), "padding" =>         // line 62
($context["padding"] ?? null), "background" =>         // line 63
($context["background"] ?? null), "stretch" => ((        // line 64
array_key_exists("is_stretched", $context)) ? (Twig\Extension\CoreExtension::default(($context["is_stretched"] ?? null), "no")) : ("no"))]], "method", false, false, true, 56);
        // line 67
        yield "
<div class=\"";
        // line 68
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["group_classes"] ?? null), "html", null, true);
        yield "\">
  ";
        // line 69
        yield from $this->unwrap()->yieldBlock('group_slot', $context, $blocks);
        // line 72
        yield "</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["stretch", "flex_direction", "items_align", "flex_align", "flex_gap", "radius", "padding", "background"]);        yield from [];
    }

    // line 69
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_group_slot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 70
        yield "
  ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:group";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  92 => 70,  85 => 69,  78 => 72,  76 => 69,  72 => 68,  69 => 67,  67 => 64,  66 => 63,  65 => 62,  64 => 61,  63 => 60,  62 => 59,  61 => 58,  60 => 57,  59 => 56,  58 => 55,  55 => 54,  53 => 3,  50 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:group", "themes/contrib/haven_theme/components/group/group.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "block" => 69];
        static $filters = ["default" => 58, "escape" => 68];
        static $functions = ["html_cva" => 4];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block'],
                ['default', 'escape'],
                ['html_cva'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
