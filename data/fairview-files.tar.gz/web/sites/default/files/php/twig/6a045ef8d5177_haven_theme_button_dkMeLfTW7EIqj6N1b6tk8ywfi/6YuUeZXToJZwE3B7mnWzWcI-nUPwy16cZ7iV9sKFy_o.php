<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:button */
class __TwigTemplate_ba32c2285457d66415d8de1b78f54267 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--button"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:button"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:button"));
        $context["button_variant"] = ((array_key_exists("variant", $context)) ? (Twig\Extension\CoreExtension::default(($context["variant"] ?? null), "primary")) : ("primary"));
        // line 2
        $context["button_size"] = ((array_key_exists("size", $context)) ? (Twig\Extension\CoreExtension::default(($context["size"] ?? null), "medium")) : ("medium"));
        // line 3
        $context["is_outlined"] = ((array_key_exists("outlined", $context)) ? (Twig\Extension\CoreExtension::default(($context["outlined"] ?? null), false)) : (false));
        // line 4
        $context["is_disabled"] = ((array_key_exists("disabled", $context)) ? (Twig\Extension\CoreExtension::default(($context["disabled"] ?? null), false)) : (false));
        // line 5
        $context["has_icon"] =  !Twig\Extension\CoreExtension::testEmpty(($context["icon"] ?? null));
        // line 6
        $context["has_label"] =  !Twig\Extension\CoreExtension::testEmpty(($context["label"] ?? null));
        // line 7
        yield "
";
        // line 8
        $context["button_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["group flex items-center justify-center transition duration-300 ease-in-out", "rounded-full leading-tight font-medium", "cursor-pointer no-underline outline-none hover:no-underline", "focus-visible:outline-1 focus-visible:outline-solid", "active:outline-1 active:outline-solid", "disabled:pointer-events-none disabled:bg-muted disabled:text-muted-foreground", (((($tmp =         // line 17
($context["is_outlined"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("border") : (""))], ["size" => ["small" => "gap-1 px-4 py-1.5 text-sm xl:py-2.5 xl:text-md", "medium" => "gap-2 px-5 py-2.5 text-md xl:py-3 xl:text-lg", "large" => "gap-3 px-6 py-3 text-lg xl:py-3.5 xl:text-xl"], "variant" => ["primary" => [(((($tmp =         // line 27
($context["is_outlined"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("border-primary text-primary") : ("bg-primary text-white")), "hover:bg-primary-dark hover:text-white", "focus-visible:border-transparent focus-visible:bg-primary-dark focus-visible:text-white focus-visible:outline-primary-light", "active:bg-primary active:text-white active:outline-primary-light"], "secondary" => [(((($tmp =         // line 33
($context["is_outlined"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("border-secondary text-secondary") : ("bg-secondary text-primary-foreground")), (((($tmp =         // line 34
($context["is_outlined"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("hover:border-secondary-dark hover:bg-accent hover:text-secondary-dark") : ("hover:bg-secondary-dark hover:text-white")), (((($tmp =         // line 35
($context["is_outlined"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("focus-visible:border-transparent focus-visible:bg-accent focus-visible:text-secondary-dark focus-visible:outline-secondary-dark") : ("focus-visible:border-transparent focus-visible:bg-secondary-dark focus-visible:text-white focus-visible:outline-secondary-light")), (((($tmp =         // line 38
($context["is_outlined"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("active:border-transparent active:bg-accent active:text-secondary active:outline-secondary-dark") : ("active:text-white active:outline-secondary-light"))], "accent" => [(((($tmp =         // line 43
($context["is_outlined"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("border-accent text-accent") : ("bg-accent text-primary")), "hover:bg-accent-dark hover:text-primary", "focus-visible:border-transparent focus-visible:bg-accent-dark focus-visible:text-primary focus-visible:outline-2 focus-visible:outline-secondary", "active:bg-accent active:text-primary active:outline-accent-light"], "light" => [(((($tmp =         // line 49
($context["is_outlined"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("border-white text-white") : ("bg-white text-primary")), (((($tmp =         // line 50
($context["is_outlined"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("hover:bg-white/30 hover:text-white") : ("hover:bg-white/60 hover:text-primary-light")), "focus-visible:border-transparent focus-visible:bg-white/30 focus-visible:text-white focus-visible:outline-muted", "active:bg-white active:text-primary active:outline-muted"]], "width" => ["full" => "w-full sm:w-fit", "fit" => "w-fit"], "iconPosition" => ["first" => "flex-row", "last" => "flex-row-reverse"]], [["size" => "small", "hasLabel" => "no", "class" => "!p-2 xl:!p-2.5"], ["size" => "medium", "hasLabel" => "no", "class" => "!p-3 xl:!p-3.5"], ["size" => "large", "hasLabel" => "no", "class" => "!p-3 xl:!p-3.5"]]);
        // line 83
        yield "
";
        // line 84
        $context["icon_size_map"] = ["small" => "extra-extra-small", "medium" => "extra-small", "large" => "small"];
        // line 89
        yield "
";
        // line 90
        $context["button_width"] = (((($tmp = ((array_key_exists("mobile_width", $context)) ? (Twig\Extension\CoreExtension::default(($context["mobile_width"] ?? null), false)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("full") : ("fit"));
        // line 91
        $context["icon_position"] = (((($tmp = ((array_key_exists("icon_first", $context)) ? (Twig\Extension\CoreExtension::default(($context["icon_first"] ?? null), false)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("first") : ("last"));
        // line 92
        $context["has_label_variant"] = (((($tmp = ($context["has_label"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 93
        $context["outlined_variant"] = (((($tmp = ($context["is_outlined"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 94
        $context["icon_classes"] = "transition duration-300 ease-in-out group-hover:translate-x-1";
        // line 95
        yield "
";
        // line 97
        $context["additional_classes"] = ((array_key_exists("btn_classes", $context)) ? (Twig\Extension\CoreExtension::default(($context["btn_classes"] ?? null), "")) : (""));
        // line 98
        if (is_iterable(($context["additional_classes"] ?? null))) {
            // line 99
            yield "  ";
            $context["additional_classes"] = Twig\Extension\CoreExtension::join(($context["additional_classes"] ?? null), " ");
        }
        // line 101
        yield "
";
        // line 103
        $context["disabled_attr"] = (((($tmp = ($context["is_disabled"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("aria-disabled=\"true\"") : (""));
        // line 104
        $context["button_disabled_attr"] = (((($tmp = ($context["is_disabled"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("disabled") : (""));
        // line 105
        $context["href"] = (((($tmp = ((array_key_exists("disabled", $context)) ? (Twig\Extension\CoreExtension::default(($context["disabled"] ?? null), false)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (null) : (($context["href"] ?? null)));
        // line 106
        yield "
";
        // line 107
        if ((($tmp = ($context["href"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 108
            yield "  <a
    href=\"";
            // line 109
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["href"] ?? null), "html", null, true);
            yield "\"
    class=\"";
            // line 110
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,             // line 111
($context["button_variants"] ?? null), "apply", [["size" =>             // line 113
($context["button_size"] ?? null), "variant" =>             // line 114
($context["button_variant"] ?? null), "width" =>             // line 115
($context["button_width"] ?? null), "iconPosition" => (((($tmp =             // line 116
($context["has_icon"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (($context["icon_position"] ?? null)) : ("last")), "hasLabel" =>             // line 117
($context["has_label_variant"] ?? null), "outlined" =>             // line 118
($context["outlined_variant"] ?? null)],             // line 120
($context["additional_classes"] ?? null)], "method", false, false, true, 111), "html", null, true);
            // line 122
            yield "\"
    ";
            // line 123
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["disabled_attr"] ?? null), "html", null, true);
            yield "
  >
    ";
            // line 125
            if ((($tmp = ($context["has_icon"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 126
                yield "      <span class=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["icon_classes"] ?? null), "html", null, true);
                yield "\">
        ";
                // line 127
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(Twig\Extension\CoreExtension::include($this->env, $context, "@haven_theme/components/icon/icon.twig", ["weight" => "bold", "icon" =>                 // line 132
($context["icon"] ?? null), "icon_size" => (($_v0 =                 // line 133
($context["icon_size_map"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess && in_array($_v0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v0[($context["button_size"] ?? null)] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["icon_size_map"] ?? null), ($context["button_size"] ?? null), [], "array", false, false, true, 133))], false));
                // line 137
                yield "
      </span>
    ";
            }
            // line 140
            yield "    ";
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("label", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "label");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "label");
                }
            }
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["label"] ?? null), "html", null, true);
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("label", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "label");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "label");
                }
            }
            yield "
  </a>
";
        } else {
            // line 143
            yield "  <button
    class=\"";
            // line 144
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,             // line 145
($context["button_variants"] ?? null), "apply", [["size" =>             // line 147
($context["button_size"] ?? null), "variant" =>             // line 148
($context["button_variant"] ?? null), "width" =>             // line 149
($context["button_width"] ?? null), "iconPosition" => (((($tmp =             // line 150
($context["has_icon"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (($context["icon_position"] ?? null)) : ("last")), "hasLabel" =>             // line 151
($context["has_label_variant"] ?? null), "outlined" =>             // line 152
($context["outlined_variant"] ?? null)],             // line 154
($context["additional_classes"] ?? null)], "method", false, false, true, 145), "html", null, true);
            // line 156
            yield "\"
    ";
            // line 157
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["button_disabled_attr"] ?? null), "html", null, true);
            yield "
  >
    ";
            // line 159
            if ((($tmp = ($context["has_icon"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 160
                yield "      <span class=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["icon_classes"] ?? null), "html", null, true);
                yield "\">
        ";
                // line 161
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(Twig\Extension\CoreExtension::include($this->env, $context, "@haven_theme/components/icon/icon.twig", ["weight" => "bold", "icon" =>                 // line 166
($context["icon"] ?? null), "icon_size" => (($_v1 =                 // line 167
($context["icon_size_map"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess && in_array($_v1::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v1[($context["button_size"] ?? null)] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["icon_size_map"] ?? null), ($context["button_size"] ?? null), [], "array", false, false, true, 167))], false));
                // line 171
                yield "
      </span>
    ";
            }
            // line 174
            yield "    ";
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("label", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "label");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "label");
                }
            }
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["label"] ?? null), "html", null, true);
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("label", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "label");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "label");
                }
            }
            yield "
  </button>
";
        }
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["variant", "size", "outlined", "disabled", "icon", "label", "mobile_width", "icon_first", "btn_classes"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:button";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  215 => 174,  210 => 171,  208 => 167,  207 => 166,  206 => 161,  201 => 160,  199 => 159,  194 => 157,  191 => 156,  189 => 154,  188 => 152,  187 => 151,  186 => 150,  185 => 149,  184 => 148,  183 => 147,  182 => 145,  181 => 144,  178 => 143,  157 => 140,  152 => 137,  150 => 133,  149 => 132,  148 => 127,  143 => 126,  141 => 125,  136 => 123,  133 => 122,  131 => 120,  130 => 118,  129 => 117,  128 => 116,  127 => 115,  126 => 114,  125 => 113,  124 => 111,  123 => 110,  119 => 109,  116 => 108,  114 => 107,  111 => 106,  109 => 105,  107 => 104,  105 => 103,  102 => 101,  98 => 99,  96 => 98,  94 => 97,  91 => 95,  89 => 94,  87 => 93,  85 => 92,  83 => 91,  81 => 90,  78 => 89,  76 => 84,  73 => 83,  71 => 50,  70 => 49,  69 => 43,  68 => 38,  67 => 35,  66 => 34,  65 => 33,  64 => 27,  63 => 17,  62 => 8,  59 => 7,  57 => 6,  55 => 5,  53 => 4,  51 => 3,  49 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:button", "themes/contrib/haven_theme/components/button/button.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "if" => 98];
        static $filters = ["default" => 1, "join" => 99, "escape" => 109];
        static $functions = ["html_cva" => 9, "include" => 128];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['default', 'join', 'escape'],
                ['html_cva', 'include'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
