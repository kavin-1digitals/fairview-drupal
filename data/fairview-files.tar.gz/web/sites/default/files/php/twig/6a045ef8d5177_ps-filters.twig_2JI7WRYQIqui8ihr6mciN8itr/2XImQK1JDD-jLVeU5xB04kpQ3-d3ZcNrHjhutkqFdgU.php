<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/provider-search/ps-filters.twig */
class __TwigTemplate_32e0c98469c5e0941fec8dfa05f3f5f7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<div class=\"ps-filters-wrap\">
  <div class=\"ps-filters\" data-ps-filters>
    <div class=\"ps-filters__lead\" aria-hidden=\"true\">
      <svg class=\"ps-filters__icon\" width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\">
        <path d=\"M2 4h12M4.5 8h7M6.5 12h3\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/>
      </svg>
      <span class=\"ps-filters__lead-text\">";
        // line 10
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("All Filters"));
        yield "</span>
    </div>

    <div class=\"ps-filter\">
      <button type=\"button\" class=\"ps-filter__trigger\" data-ps-filter-trigger aria-expanded=\"false\" aria-controls=\"ps-panel-location\" id=\"ps-btn-location\">
        <span class=\"ps-filter__trigger-label\">";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Location"));
        yield "</span>
      </button>
      <div class=\"ps-filter__panel\" id=\"ps-panel-location\" data-ps-filter-panel hidden>
        <div class=\"ps-filter__panel-head\">
          <h2 class=\"ps-filter__title\" id=\"ps-panel-location-title\">";
        // line 19
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Location"));
        yield "</h2>
          <button type=\"button\" class=\"ps-filter__panel-close\" data-ps-filter-close aria-label=\"";
        // line 20
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Close"));
        yield "\">
            <svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 4l8 8M12 4L4 12\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/></svg>
          </button>
        </div>
        <div class=\"ps-filter__panel-body\">
          <div class=\"ps-filter__row\">
            <span class=\"ps-filter__within\">";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Within"));
        yield "</span>
            <select class=\"ps-filter__select ps-filter__select--grow\" name=\"radius\" aria-labelledby=\"ps-panel-location-title\">
              <option>any miles</option>
              <option>5 miles</option>
              <option>10 miles</option>
              <option>25 miles</option>
              <option>50 miles</option>
              <option>100 miles</option>
            </select>
          </div>
          <label class=\"ps-filter__field-label\" for=\"ps-loc-input\">";
        // line 36
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("City, State or Zip"));
        yield "</label>
          <input id=\"ps-loc-input\" type=\"text\" class=\"ps-filter__input\" placeholder=\"";
        // line 37
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("City, State or Zip"));
        yield "\" autocomplete=\"address-level2\" />
          <button type=\"button\" class=\"ps-filter__linkish\">";
        // line 38
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Use current location"));
        yield "</button>
        </div>
      </div>
    </div>

    <div class=\"ps-filter\">
      <button type=\"button\" class=\"ps-filter__trigger\" data-ps-filter-trigger aria-expanded=\"false\" aria-controls=\"ps-panel-book\" id=\"ps-btn-book\">
        <span class=\"ps-filter__trigger-label\">";
        // line 45
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Book Online"));
        yield "</span>
      </button>
      <div class=\"ps-filter__panel\" id=\"ps-panel-book\" data-ps-filter-panel hidden>
        <div class=\"ps-filter__panel-head\">
          <h2 class=\"ps-filter__title\">";
        // line 49
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Book Online"));
        yield "</h2>
          <button type=\"button\" class=\"ps-filter__panel-close\" data-ps-filter-close aria-label=\"";
        // line 50
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Close"));
        yield "\">
            <svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 4l8 8M12 4L4 12\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/></svg>
          </button>
        </div>
        <div class=\"ps-filter__panel-body\">
          <label class=\"ps-check\">
            <input type=\"checkbox\" name=\"book_online\" />
            <span>";
        // line 57
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Book Online (508)"));
        yield "</span>
          </label>
        </div>
      </div>
    </div>

    <div class=\"ps-filter\">
      <button type=\"button\" class=\"ps-filter__trigger\" data-ps-filter-trigger aria-expanded=\"false\" aria-controls=\"ps-panel-spec\" id=\"ps-btn-spec\">
        <span class=\"ps-filter__trigger-label\">";
        // line 65
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Specialty"));
        yield "</span>
      </button>
      <div class=\"ps-filter__panel\" id=\"ps-panel-spec\" data-ps-filter-panel hidden>
        <div class=\"ps-filter__panel-head\">
          <h2 class=\"ps-filter__title\">";
        // line 69
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Specialty"));
        yield "</h2>
          <button type=\"button\" class=\"ps-filter__panel-close\" data-ps-filter-close aria-label=\"";
        // line 70
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Close"));
        yield "\">
            <svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 4l8 8M12 4L4 12\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/></svg>
          </button>
        </div>
        <div class=\"ps-filter__panel-body\">
          <label class=\"visually-hidden\" for=\"ps-spec-input\">";
        // line 75
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Specialty"));
        yield "</label>
          <input id=\"ps-spec-input\" type=\"search\" class=\"ps-filter__input\" placeholder=\"";
        // line 76
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Type here..."));
        yield "\" />
        </div>
      </div>
    </div>

    <div class=\"ps-filter\">
      <button type=\"button\" class=\"ps-filter__trigger\" data-ps-filter-trigger aria-expanded=\"false\" aria-controls=\"ps-panel-ins\" id=\"ps-btn-ins\">
        <span class=\"ps-filter__trigger-label\">";
        // line 83
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Insurance Accepted"));
        yield "</span>
      </button>
      <div class=\"ps-filter__panel\" id=\"ps-panel-ins\" data-ps-filter-panel hidden>
        <div class=\"ps-filter__panel-head\">
          <h2 class=\"ps-filter__title\">";
        // line 87
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Insurance Accepted"));
        yield "</h2>
          <button type=\"button\" class=\"ps-filter__panel-close\" data-ps-filter-close aria-label=\"";
        // line 88
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Close"));
        yield "\">
            <svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 4l8 8M12 4L4 12\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/></svg>
          </button>
        </div>
        <div class=\"ps-filter__panel-body\">
          <label class=\"visually-hidden\" for=\"ps-ins-input\">";
        // line 93
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Insurance Accepted"));
        yield "</label>
          <input id=\"ps-ins-input\" type=\"search\" class=\"ps-filter__input\" placeholder=\"";
        // line 94
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Type here..."));
        yield "\" />
        </div>
      </div>
    </div>

    <div class=\"ps-filter\">
      <button type=\"button\" class=\"ps-filter__trigger\" data-ps-filter-trigger aria-expanded=\"false\" aria-controls=\"ps-panel-gender\" id=\"ps-btn-gender\">
        <span class=\"ps-filter__trigger-label\">";
        // line 101
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Gender"));
        yield "</span>
      </button>
      <div class=\"ps-filter__panel\" id=\"ps-panel-gender\" data-ps-filter-panel hidden>
        <div class=\"ps-filter__panel-head\">
          <h2 class=\"ps-filter__title\">";
        // line 105
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Gender"));
        yield "</h2>
          <button type=\"button\" class=\"ps-filter__panel-close\" data-ps-filter-close aria-label=\"";
        // line 106
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Close"));
        yield "\">
            <svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 4l8 8M12 4L4 12\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/></svg>
          </button>
        </div>
        <div class=\"ps-filter__panel-body\">
          <label class=\"ps-check\"><input type=\"checkbox\" name=\"g_f\" /> <span>";
        // line 111
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Female (2178)"));
        yield "</span></label>
          <label class=\"ps-check\"><input type=\"checkbox\" name=\"g_m\" /> <span>";
        // line 112
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Male (1186)"));
        yield "</span></label>
          <label class=\"ps-check\"><input type=\"checkbox\" name=\"g_nb\" /> <span>";
        // line 113
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Non-binary (2)"));
        yield "</span></label>
        </div>
      </div>
    </div>

    <div class=\"ps-filter\">
      <button type=\"button\" class=\"ps-filter__trigger\" data-ps-filter-trigger aria-expanded=\"false\" aria-controls=\"ps-panel-pro\" id=\"ps-btn-pro\">
        <span class=\"ps-filter__trigger-label\">";
        // line 120
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Pronouns"));
        yield "</span>
      </button>
      <div class=\"ps-filter__panel\" id=\"ps-panel-pro\" data-ps-filter-panel hidden>
        <div class=\"ps-filter__panel-head\">
          <h2 class=\"ps-filter__title\">";
        // line 124
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Pronouns"));
        yield "</h2>
          <button type=\"button\" class=\"ps-filter__panel-close\" data-ps-filter-close aria-label=\"";
        // line 125
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Close"));
        yield "\">
            <svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\"><path d=\"M4 4l8 8M12 4L4 12\" stroke=\"currentColor\" stroke-width=\"1.5\" stroke-linecap=\"round\"/></svg>
          </button>
        </div>
        <div class=\"ps-filter__panel-body\">
          <label class=\"ps-check\"><input type=\"checkbox\" /> <span>";
        // line 130
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Ask Me (1)"));
        yield "</span></label>
          <label class=\"ps-check\"><input type=\"checkbox\" /> <span>";
        // line 131
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("He, Him (137)"));
        yield "</span></label>
          <label class=\"ps-check\"><input type=\"checkbox\" /> <span>";
        // line 132
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("He, They (1)"));
        yield "</span></label>
          <label class=\"ps-check\"><input type=\"checkbox\" /> <span>";
        // line 133
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("She, Her (367)"));
        yield "</span></label>
          <label class=\"ps-check\"><input type=\"checkbox\" /> <span>";
        // line 134
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("She, They (3)"));
        yield "</span></label>
          <div class=\"ps-filter__more\" data-ps-pronouns-more hidden>
            <label class=\"ps-check\"><input type=\"checkbox\" /> <span>";
        // line 136
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("They, Them (12)"));
        yield "</span></label>
            <label class=\"ps-check\"><input type=\"checkbox\" /> <span>";
        // line 137
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Other (4)"));
        yield "</span></label>
          </div>
          <button type=\"button\" class=\"ps-filter__show-more\" data-ps-show-more>";
        // line 139
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Show More"));
        yield "</button>
        </div>
      </div>
    </div>

  </div>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/provider-search/ps-filters.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  295 => 139,  290 => 137,  286 => 136,  281 => 134,  277 => 133,  273 => 132,  269 => 131,  265 => 130,  257 => 125,  253 => 124,  246 => 120,  236 => 113,  232 => 112,  228 => 111,  220 => 106,  216 => 105,  209 => 101,  199 => 94,  195 => 93,  187 => 88,  183 => 87,  176 => 83,  166 => 76,  162 => 75,  154 => 70,  150 => 69,  143 => 65,  132 => 57,  122 => 50,  118 => 49,  111 => 45,  101 => 38,  97 => 37,  93 => 36,  80 => 26,  71 => 20,  67 => 19,  60 => 15,  52 => 10,  44 => 4,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/provider-search/ps-filters.twig", "/var/www/html/web/themes/custom/fairview/components/provider-search/ps-filters.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["t" => 10];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['t'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
