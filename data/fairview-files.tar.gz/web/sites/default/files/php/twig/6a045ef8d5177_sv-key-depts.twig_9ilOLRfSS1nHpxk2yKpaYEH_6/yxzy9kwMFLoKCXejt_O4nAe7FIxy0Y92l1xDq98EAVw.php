<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/services/sv-key-depts.twig */
class __TwigTemplate_1db5d432682fea1c933abca5ea0dd8cc extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"sv-key\" aria-labelledby=\"sv-key-title\">
  <div class=\"sv-key__inner\">
    <h2 id=\"sv-key-title\" class=\"sv-key__title\">";
        // line 9
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_key_depts_title", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_key_depts_title"] ?? null), "")) : ("")), "html", null, true);
        yield "</h2>
    <ul class=\"sv-key__grid\">
      ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("sv_key_dept_cards", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_key_dept_cards"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["card"]) {
            // line 12
            yield "        <li class=\"sv-key__cell\">
          <a class=\"sv-key-card\" href=\"";
            // line 13
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((CoreExtension::getAttribute($this->env, $this->source, $context["card"], "url", [], "any", true, true, true, 13)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["card"], "url", [], "any", false, false, true, 13), "#")) : ("#")), "html", null, true);
            yield "\">
            <span class=\"sv-key-card__icon-wrap\" aria-hidden=\"true\">
              ";
            // line 15
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["card"], "icon", [], "any", false, false, true, 15)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 16
                yield "                <img class=\"sv-key-card__icon\" src=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_img_base", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_img_base"] ?? null), "")) : ("")), "html", null, true);
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["card"], "icon", [], "any", false, false, true, 16), "html", null, true);
                yield "\" width=\"40\" height=\"40\" alt=\"\" loading=\"lazy\" />
              ";
            }
            // line 18
            yield "            </span>
            <span class=\"sv-key-card__label\">";
            // line 19
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["card"], "label", [], "any", false, false, true, 19), "html", null, true);
            yield "</span>
          </a>
        </li>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['card'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        yield "    </ul>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["sv_key_depts_title", "sv_key_dept_cards", "sv_img_base"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/services/sv-key-depts.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  87 => 23,  77 => 19,  74 => 18,  67 => 16,  65 => 15,  60 => 13,  57 => 12,  53 => 11,  48 => 9,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/services/sv-key-depts.twig", "/var/www/html/web/themes/custom/fairview/components/services/sv-key-depts.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 11, "if" => 15];
        static $filters = ["escape" => 9, "default" => 9];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if'],
                ['escape', 'default'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
