<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/fairview/templates/layout/page--search.html.twig */
class __TwigTemplate_3c7d4c5903ea1bcf7e83ff94271428a7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_body' => [$this, 'block_page_body'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@fairview/templates/layout/page.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@fairview/templates/layout/page.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<div class=\"provider-search\" data-provider-search>
  ";
        // line 5
        yield from $this->load("@fairview/components/provider-search/ps-top-bar.twig", 5)->unwrap()->yield($context);
        // line 6
        yield "  <div class=\"provider-search__shell\">
    ";
        // line 7
        yield from $this->load("@fairview/components/provider-search/ps-alert.twig", 7)->unwrap()->yield($context);
        // line 8
        yield "    ";
        yield from $this->load("@fairview/components/provider-search/ps-filters.twig", 8)->unwrap()->yield($context);
        // line 9
        yield "    ";
        yield from $this->load("@fairview/components/provider-search/ps-cards.twig", 9)->unwrap()->yield($context);
        // line 10
        yield "  </div>
  ";
        // line 11
        yield from $this->load("@fairview/components/contact-banner/contact-banner.twig", 11)->unwrap()->yield($context);
        // line 12
        yield "</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/fairview/templates/layout/page--search.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  81 => 12,  79 => 11,  76 => 10,  73 => 9,  70 => 8,  68 => 7,  65 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/fairview/templates/layout/page--search.html.twig", "/var/www/html/web/themes/custom/fairview/templates/layout/page--search.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["extends" => 1, "include" => 5];
        static $filters = [];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['extends', 'include'],
                [],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
