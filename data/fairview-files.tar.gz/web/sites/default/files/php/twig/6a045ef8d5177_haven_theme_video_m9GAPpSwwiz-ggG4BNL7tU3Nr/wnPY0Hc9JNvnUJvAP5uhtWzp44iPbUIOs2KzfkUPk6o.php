<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:video */
class __TwigTemplate_f18880551cb5a3aa0fa240ae65c4808d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--video"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:video"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:video"));
        $context["video_attributes"] = ((array_key_exists("video_attributes", $context)) ? (Twig\Extension\CoreExtension::default(($context["video_attributes"] ?? null), $this->extensions['Drupal\Core\Template\TwigExtension']->createAttribute())) : ($this->extensions['Drupal\Core\Template\TwigExtension']->createAttribute()));
        // line 2
        yield "
";
        // line 4
        $context["video_autoplay"] = ((($context["autoplay"] ?? null)) ? ($context["autoplay"]) : (false));
        // line 5
        $context["video_muted"] = ((($context["muted"] ?? null)) ? ($context["muted"]) : (false));
        // line 6
        $context["video_loop"] = ((($context["loop"] ?? null)) ? ($context["loop"]) : (false));
        // line 7
        $context["video_aria_label"] = ((($context["caption"] ?? null)) ? ($context["caption"]) : (false));
        // line 8
        $context["video_poster"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["poster"] ?? null), "src", [], "any", false, false, true, 8)) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["poster"] ?? null), "src", [], "any", false, false, true, 8)) : (false));
        // line 9
        $context["is_autoplay"] = (((($tmp = ($context["autoplay"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 10
        yield "
<figure class=\"video-component cq-full grid w-full gap-2 relative\">
  <video
    ";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["video_attributes"] ?? null), "setAttribute", ["autoplay",         // line 14
($context["video_autoplay"] ?? null)], "method", false, false, true, 13), "setAttribute", ["muted",         // line 15
($context["video_muted"] ?? null)], "method", false, false, true, 14), "setAttribute", ["loop",         // line 16
($context["video_loop"] ?? null)], "method", false, false, true, 15), "setAttribute", ["aria-label",         // line 17
($context["video_aria_label"] ?? null)], "method", false, false, true, 16), "setAttribute", ["poster",         // line 18
($context["video_poster"] ?? null)], "method", false, false, true, 17), "html", null, true);
        // line 19
        yield "
    src=\"";
        // line 20
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["media"] ?? null), "src", [], "any", false, false, true, 20), "html", null, true);
        yield "\"
    class=\"h-auto w-full rounded-lg aspect-video object-cover\"
  >
    Your browser does not support the video tag.
  </video>
  ";
        // line 25
        if ((($tmp = ($context["controls"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 26
            yield "    <div class=\"video-controls absolute bottom-4 right-4 flex items-center gap-2\">
      <button
        aria-label=\"";
            // line 28
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((((($tmp = ($context["autoplay"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("Pause video") : ("Play video")));
            yield "\"
        class=\"text-white cursor-pointer\"
      >
        <span class=\"video-icon-play";
            // line 31
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((((($tmp = ($context["autoplay"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (" hidden") : ("")));
            yield "\">
          ";
            // line 32
            yield from $this->load("haven_theme:icon", 32)->unwrap()->yield(CoreExtension::toArray(["icon" => "play-circle", "icon_size" => "large"]));
            // line 36
            yield "        </span>
        <span class=\"video-icon-pause";
            // line 37
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar((((($tmp = ($context["autoplay"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("") : (" hidden")));
            yield "\">
          ";
            // line 38
            yield from $this->load("haven_theme:icon", 38)->unwrap()->yield(CoreExtension::toArray(["icon" => "pause-circle", "icon_size" => "large"]));
            // line 42
            yield "        </span>
      </button>
    </div>
  ";
        }
        // line 46
        yield "</figure>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["autoplay", "muted", "loop", "caption", "poster", "media", "controls"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:video";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  120 => 46,  114 => 42,  112 => 38,  108 => 37,  105 => 36,  103 => 32,  99 => 31,  93 => 28,  89 => 26,  87 => 25,  79 => 20,  76 => 19,  74 => 18,  73 => 17,  72 => 16,  71 => 15,  70 => 14,  69 => 13,  64 => 10,  62 => 9,  60 => 8,  58 => 7,  56 => 6,  54 => 5,  52 => 4,  49 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:video", "themes/contrib/haven_theme/components/video/video.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "if" => 25, "include" => 32];
        static $filters = ["default" => 1, "escape" => 18];
        static $functions = ["create_attribute" => 1];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'include'],
                ['default', 'escape'],
                ['create_attribute'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
