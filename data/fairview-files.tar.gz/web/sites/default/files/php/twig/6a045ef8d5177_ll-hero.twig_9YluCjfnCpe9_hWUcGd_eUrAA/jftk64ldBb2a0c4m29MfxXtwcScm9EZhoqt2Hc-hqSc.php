<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/location-list/ll-hero.twig */
class __TwigTemplate_af732d0bd942e6ffc5075254ccbef860 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<section class=\"ll-hero\" aria-labelledby=\"ll-hero-title\">
  <h1 id=\"ll-hero-title\" class=\"visually-hidden\">";
        // line 5
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Find a location"));
        yield "</h1>
  <form class=\"ll-hero__form\" role=\"search\" action=\"/locations/list\" method=\"get\" data-ll-hero-form>
    <div class=\"ll-hero__fields\">
      <div class=\"ll-hero__field\" data-ll-field=\"primary\">
        <label class=\"ll-hero__label\" for=\"ll-input-primary\">";
        // line 9
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Enter name, service, or specialty"));
        yield "</label>
        <div class=\"ll-hero__control\">
          <input type=\"search\" id=\"ll-input-primary\" name=\"q\" class=\"ll-hero__input\" placeholder=\"";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Begin typing..."));
        yield "\" autocomplete=\"off\" data-ll-input-primary />
          <div class=\"ll-dropdown\" id=\"ll-dd-primary\" data-ll-dropdown=\"primary\" hidden>
            <p class=\"ll-dropdown__heading\">";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Popular Searches"));
        yield "</p>
            <ul class=\"ll-dropdown__list\" role=\"listbox\">
              ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("ll_popular_searches", $context)) ? (Twig\Extension\CoreExtension::default(($context["ll_popular_searches"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 16
            yield "                <li role=\"none\"><button type=\"button\" class=\"ll-dropdown__opt\" data-ll-suggest=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $context["item"], "html", null, true);
            yield "\">";
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("item", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "item");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "item");
                }
            }
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $context["item"], "html", null, true);
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("item", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "item");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "item");
                }
            }
            yield "</button></li>
              ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        yield "            </ul>
          </div>
        </div>
      </div>
      <div class=\"ll-hero__field\" data-ll-field=\"near\">
        <label class=\"ll-hero__label\" for=\"ll-input-near\">";
        // line 23
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Search Near"));
        yield "</label>
        <div class=\"ll-hero__control\">
          <input type=\"search\" id=\"ll-input-near\" name=\"near\" class=\"ll-hero__input\" placeholder=\"";
        // line 25
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Enter address, city, or ZIP code"));
        yield "\" autocomplete=\"off\" data-ll-input-near />
          <div class=\"ll-dropdown\" id=\"ll-dd-near\" data-ll-dropdown=\"near\" hidden>
            <button type=\"button\" class=\"ll-dropdown__loc\" data-ll-use-location>
              <span class=\"ll-dropdown__loc-icon\" aria-hidden=\"true\">
                <svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\"><path d=\"M12 21s7-4.35 7-10a7 7 0 1 0-14 0c0 5.65 7 10 7 10z\" stroke=\"currentColor\" stroke-width=\"1.5\"/><circle cx=\"12\" cy=\"11\" r=\"2.5\" stroke=\"currentColor\" stroke-width=\"1.5\"/></svg>
              </span>
              <span>";
        // line 31
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Use my current location"));
        yield "</span>
            </button>
          </div>
        </div>
      </div>
    </div>
    <button type=\"submit\" class=\"ll-hero__submit\" aria-label=\"";
        // line 37
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Search"));
        yield "\">
      <svg width=\"20\" height=\"20\" viewBox=\"0 0 24 24\" fill=\"none\" aria-hidden=\"true\"><path d=\"M5 12h14M13 6l6 6-6 6\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>
    </button>
  </form>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["ll_popular_searches"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/location-list/ll-hero.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  128 => 37,  119 => 31,  110 => 25,  105 => 23,  98 => 18,  73 => 16,  69 => 15,  64 => 13,  59 => 11,  54 => 9,  47 => 5,  44 => 4,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/location-list/ll-hero.twig", "/var/www/html/web/themes/custom/fairview/components/location-list/ll-hero.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 15];
        static $filters = ["t" => 5, "default" => 15, "escape" => 16];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['t', 'default', 'escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
