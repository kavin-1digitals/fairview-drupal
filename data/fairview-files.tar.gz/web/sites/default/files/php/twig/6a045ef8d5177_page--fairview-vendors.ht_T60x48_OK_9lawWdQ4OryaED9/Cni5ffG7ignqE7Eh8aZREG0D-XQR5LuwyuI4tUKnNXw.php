<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* themes/custom/fairview/templates/layout/page--fairview-vendors.html.twig */
class __TwigTemplate_23770e052dba24980f6e5a88a0a463d8 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_body' => [$this, 'block_page_body'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@fairview/templates/layout/page.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@fairview/templates/layout/page.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<div class=\"fv-vendors-page\">
  <header class=\"fv-vendors-hero\">
    <div class=\"fv-vendors-hero__inner\">
      <h1 class=\"fv-vendors-hero__title\">";
        // line 7
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview Vendors"));
        yield "</h1>
    </div>
  </header>

  <section class=\"fv-vendors-intro\" aria-label=\"";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Introduction"));
        yield "\">
    <div class=\"fv-vendors-intro__inner\">
      <p class=\"fv-vendors-intro__text\">
        ";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("By leveraging Fairview’s size and expertise, our affiliates take advantage of Fairview’s long history of quality services in the upper Midwest."));
        yield "
      </p>
    </div>
  </section>

  <section class=\"fv-vendors-work\" aria-labelledby=\"fv-vendors-work-title\">
    <div class=\"fv-vendors-work__inner\">
      <h2 id=\"fv-vendors-work-title\" class=\"fv-vendors-work__heading\">";
        // line 21
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Working with Fairview"));
        yield "</h2>
      <div class=\"fv-vendors-cols\">
        <div class=\"fv-vendors-col\">
          <h3 class=\"fv-vendors-col__title\">";
        // line 24
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview Purchasing Network"));
        yield "</h3>
          <p class=\"fv-vendors-col__body\">
            ";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview Purchasing Network (FPN), a division of Fairview Health Services, is a Premier-sponsored group purchasing organization (GPO) affiliate program. We offer supply savings and consulting services that enhance our members’ purchasing power. Our affiliates include over 20 acute care hospitals, seven alternate care sites and 13 retail pharmacies in the upper Midwest."));
        yield "
          </p>
          <ul class=\"fv-vendors-links\" role=\"list\">
            <li><a class=\"fv-vendors-arrow-link\" href=\"/fairview-vendors/fpn/overview\">";
        // line 29
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Overview"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
            <li><a class=\"fv-vendors-arrow-link\" href=\"/fairview-vendors/fpn/partners\">";
        // line 30
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Partners"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
          </ul>
        </div>
        <div class=\"fv-vendors-col\">
          <h3 class=\"fv-vendors-col__title\">";
        // line 34
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Vendor Information"));
        yield "</h3>
          <p class=\"fv-vendors-col__body\">
            ";
        // line 36
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview and HealthEast make an effort to work with organizations whose values and standards of conduct match our own. All business partners and individual vendor representatives who conduct business with any Fairview location must complete the vendor certification process. HealthEast integrated with Fairview Health Services in 2017."));
        yield "
          </p>
          <ul class=\"fv-vendors-links\" role=\"list\">
            <li><a class=\"fv-vendors-arrow-link\" href=\"/fairview-vendors/certification\">";
        // line 39
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview Vendor Certification Program"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
            <li><a class=\"fv-vendors-arrow-link\" href=\"/fairview-vendors/new-product\">";
        // line 40
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("New Product Introduction"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
          </ul>
        </div>
      </div>
    </div>
  </section>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "themes/custom/fairview/templates/layout/page--fairview-vendors.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  131 => 40,  127 => 39,  121 => 36,  116 => 34,  109 => 30,  105 => 29,  99 => 26,  94 => 24,  88 => 21,  78 => 14,  72 => 11,  65 => 7,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "themes/custom/fairview/templates/layout/page--fairview-vendors.html.twig", "/var/www/html/web/themes/custom/fairview/templates/layout/page--fairview-vendors.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["extends" => 1];
        static $filters = ["t" => 7];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['extends'],
                ['t'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
