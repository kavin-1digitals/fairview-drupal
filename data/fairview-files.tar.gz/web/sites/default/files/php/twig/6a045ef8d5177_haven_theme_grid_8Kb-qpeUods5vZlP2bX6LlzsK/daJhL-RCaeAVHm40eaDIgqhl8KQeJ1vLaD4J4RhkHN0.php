<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:grid */
class __TwigTemplate_f0a1013c891bd26491f26104f77661f1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'main_slot' => [$this, 'block_main_slot'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--grid"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:grid"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:grid"));
        $context["is_reverse"] = (((($tmp = ($context["reverse_mobile"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 2
        yield "
";
        // line 3
        $context["section"] = Twig\Extra\Html\HtmlExtension::htmlCva(["relative mx-auto flex flex-col items-stretch"], ["width" => ["100%" => "lg:max-w-full", "90%" => "lg:max-w-9/10", "80%" => "lg:max-w-8/10", "70%" => "lg:max-w-7/10", "60%" => "lg:max-w-6/10", "50%" => "lg:max-w-1/2"]]);
        // line 18
        yield "
";
        // line 19
        $context["section_content"] = CoreExtension::getAttribute($this->env, $this->source,         // line 20
($context["section"] ?? null), "apply", [["width" => ((        // line 21
array_key_exists("width", $context)) ? (Twig\Extension\CoreExtension::default(($context["width"] ?? null), "100%")) : ("100%"))]], "method", false, false, true, 20);
        // line 24
        yield "
";
        // line 25
        $context["grid"] = Twig\Extra\Html\HtmlExtension::htmlCva(["grid w-full min-w-0", "gap-4 @sm:gap-6 @3xl:gap-8"], ["columns" => ["1 column" => "grid-cols-1", "2 columns" => "md:grid-cols-2", "3 columns" => "md:grid-cols-3", "4 columns" => "sm:grid-cols-2 lg:grid-cols-4", "5 columns" => "sm:grid-cols-2 lg:grid-cols-5", "6 columns" => "sm:grid-cols-3 lg:grid-cols-6", "2 columns 75%-25%" => "md:grid-cols-[minmax(0,3fr)_minmax(0,1fr)]", "2 columns 25%-75%" => "md:grid-cols-[minmax(0,1fr)_minmax(0,3fr)]", "2 columns 67%-33%" => "md:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]", "2 columns 33%-67%" => "md:grid-cols-[minmax(0,1fr)_minmax(0,2fr)]", "3 columns 50%-25%-25%" => "md:grid-cols-[minmax(0,2fr)_minmax(0,1fr)_minmax(0,1fr)]", "3 columns 25%-25%-50%" => "md:grid-cols-[minmax(0,1fr)_minmax(0,1fr)_minmax(0,2fr)]"], "mobileColumns" => ["1" => "", "2" => "grid-cols-2", "3" => "grid-cols-3"], "reverseMobile" => ["yes" => "[&>*:first-child]:order-1 md:[&>*:first-child]:-order-1 [&>*:last-child]:-order-1 md:[&>*:last-child]:order-1"]], [["columns" => ["4 columns"], "mobileColumns" => ["2"], "class" => "sm:grid-cols-4"]]);
        // line 61
        yield "
";
        // line 62
        $context["grid_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 63
($context["grid"] ?? null), "apply", [["columns" => ((        // line 64
array_key_exists("columns", $context)) ? (Twig\Extension\CoreExtension::default(($context["columns"] ?? null), "100")) : ("100")), "mobileColumns" => ((        // line 65
array_key_exists("mobile_columns", $context)) ? (Twig\Extension\CoreExtension::default(($context["mobile_columns"] ?? null), "1")) : ("1"))]], "method", false, false, true, 63);
        // line 68
        yield "
<section class=\"";
        // line 69
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["section_classes"] ?? null), "html", null, true);
        yield "\">
  <div class=\"";
        // line 70
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["section_content"] ?? null), "html", null, true);
        yield "\">
    <div class=\"";
        // line 71
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["grid_classes"] ?? null), "html", null, true);
        yield "\">
      ";
        // line 72
        yield from $this->unwrap()->yieldBlock('main_slot', $context, $blocks);
        // line 75
        yield "    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["reverse_mobile", "width", "columns", "mobile_columns", "section_classes"]);        yield from [];
    }

    // line 72
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main_slot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 73
        yield "
      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:grid";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  108 => 73,  101 => 72,  92 => 75,  90 => 72,  86 => 71,  82 => 70,  78 => 69,  75 => 68,  73 => 65,  72 => 64,  71 => 63,  70 => 62,  67 => 61,  65 => 25,  62 => 24,  60 => 21,  59 => 20,  58 => 19,  55 => 18,  53 => 3,  50 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:grid", "themes/contrib/haven_theme/components/grid/grid.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "block" => 72];
        static $filters = ["default" => 21, "escape" => 69];
        static $functions = ["html_cva" => 4];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block'],
                ['default', 'escape'],
                ['html_cva'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
