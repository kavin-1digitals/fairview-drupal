<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:card */
class __TwigTemplate_3f039d7a193cba3e00cd8b1da262ce48 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'media' => [$this, 'block_media'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--card"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:card"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:card"));
        $context["is_clickable"] = (((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["url"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 2
        yield "
";
        // line 3
        $context["card"] = Twig\Extra\Html\HtmlExtension::htmlCva(["group relative", "flex flex-col justify-between gap-8", "rounded-[20px] bg-white", "p-4", "text-black", "transition duration-300", "in-[.views-row]:h-full"], ["clickable" => ["yes" => "hover:scale-104 hover:shadow-2xl", "no" => ""]]);
        // line 22
        yield "
";
        // line 23
        $context["card_media"] = Twig\Extra\Html\HtmlExtension::htmlCva("mt-auto aspect-video overflow-hidden rounded-sm", []);
        // line 24
        yield "
";
        // line 25
        $context["card_content"] = Twig\Extra\Html\HtmlExtension::htmlCva("@container flex w-full flex-col items-baseline gap-4", []);
        // line 26
        yield "
<div
  class=\"";
        // line 28
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,         // line 29
($context["card"] ?? null), "apply", [["clickable" =>         // line 31
($context["is_clickable"] ?? null)], ((        // line 33
array_key_exists("card_classes", $context)) ? (Twig\Extension\CoreExtension::default(($context["card_classes"] ?? null), "")) : (""))], "method", false, false, true, 29), "html", null, true);
        // line 35
        yield "\"
>
  <div
    class=\"";
        // line 38
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,         // line 39
($context["card_content"] ?? null), "apply", [["style" =>         // line 40
($context["card_style"] ?? null)]], "method", false, false, true, 39), "html", null, true);
        // line 42
        yield "\"
  >
    ";
        // line 44
        if ((($tmp = ($context["category"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 45
            yield "      <header class=\"flex items-center gap-x-2 text-sm text-accent-foreground\">
        ";
            // line 46
            try {
                $_v0 = $this->load("@haven_theme/components/icon/icon.twig", 46);
            } catch (LoaderError $e) {
                // ignore missing template
                $_v0 = null;
            }
            if ($_v0) {
                yield from $_v0->unwrap()->yield(CoreExtension::toArray(["icon" =>                 // line 47
($context["icon"] ?? null), "icon_size" => "extra-small", "icon_color" => "currentColor", "alt" =>                 // line 50
($context["category"] ?? null)]));
            }
            // line 52
            yield "        ";
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("category", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "category");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "category");
                }
            }
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["category"] ?? null), "html", null, true);
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("category", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "category");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "category");
                }
            }
            yield "
      </header>
    ";
        }
        // line 55
        yield "    <h3 class=\"text-xl font-semibold text-primary @sm:text-2xl @2xl:text-3xl\">
      ";
        // line 56
        if ((($tmp = ($context["is_clickable"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 57
            yield "        <a href=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["url"] ?? null), "html", null, true);
            yield "\" class=\"after:absolute after:inset-0 after:content-['']\">";
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("heading_text", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "heading_text");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "heading_text");
                }
            }
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["heading_text"] ?? null), "html", null, true);
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("heading_text", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "heading_text");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "heading_text");
                }
            }
            yield "</a>
      ";
        }
        // line 59
        yield "    </h3>
  </div>

  <div class=\"@container flex w-full flex-col gap-2 md:gap-3\">
    ";
        // line 63
        if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["date"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 64
            yield "      <span class=\"text-xs @sm:text-sm\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Twig\Extension\CoreExtension']->formatDate(($context["date"] ?? null), "j F Y"), "html", null, true);
            yield "</span>
    ";
        }
        // line 66
        yield "    ";
        if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["media"] ?? null), "src", [], "any", false, false, true, 66))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 67
            yield "      <div
        class=\"";
            // line 68
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,             // line 69
($context["card_media"] ?? null), "apply", [["style" =>             // line 70
($context["card_style"] ?? null)]], "method", false, false, true, 69), "html", null, true);
            // line 72
            yield "\"
      >
        ";
            // line 74
            yield from $this->unwrap()->yieldBlock('media', $context, $blocks);
            // line 84
            yield "      </div>
    ";
        }
        // line 86
        yield "  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["url", "card_classes", "card_style", "category", "icon", "heading_text", "date", "media", "card_orientation"]);        yield from [];
    }

    // line 74
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_media(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 75
        yield "          ";
        try {
            $_v1 = $this->load("canvas:image", 75);
        } catch (LoaderError $e) {
            // ignore missing template
            $_v1 = null;
        }
        if ($_v1) {
            yield from $_v1->unwrap()->yield(CoreExtension::toArray(["src" => CoreExtension::getAttribute($this->env, $this->source,             // line 76
($context["media"] ?? null), "src", [], "any", false, false, true, 76), "alt" => CoreExtension::getAttribute($this->env, $this->source,             // line 77
($context["media"] ?? null), "alt", [], "any", false, false, true, 77), "class" => "object-cover w-full h-full", "width" => CoreExtension::getAttribute($this->env, $this->source,             // line 79
($context["media"] ?? null), "width", [], "any", false, false, true, 79), "height" => CoreExtension::getAttribute($this->env, $this->source,             // line 80
($context["media"] ?? null), "height", [], "any", false, false, true, 80), "sizes" => (((            // line 81
($context["card_orientation"] ?? null) == "stacked")) ? ("auto, 100vw") : ("50vw"))]));
        }
        // line 83
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:card";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  217 => 83,  214 => 81,  213 => 80,  212 => 79,  211 => 77,  210 => 76,  201 => 75,  194 => 74,  186 => 86,  182 => 84,  180 => 74,  176 => 72,  174 => 70,  173 => 69,  172 => 68,  169 => 67,  166 => 66,  160 => 64,  158 => 63,  152 => 59,  130 => 57,  128 => 56,  125 => 55,  104 => 52,  101 => 50,  100 => 47,  92 => 46,  89 => 45,  87 => 44,  83 => 42,  81 => 40,  80 => 39,  79 => 38,  74 => 35,  72 => 33,  71 => 31,  70 => 29,  69 => 28,  65 => 26,  63 => 25,  60 => 24,  58 => 23,  55 => 22,  53 => 3,  50 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:card", "themes/contrib/haven_theme/components/card/card.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "if" => 44, "include" => 46, "block" => 74];
        static $filters = ["escape" => 29, "default" => 33, "date" => 64];
        static $functions = ["html_cva" => 4];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'include', 'block'],
                ['escape', 'default', 'date'],
                ['html_cva'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
