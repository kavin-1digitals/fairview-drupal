<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:hero-billboard */
class __TwigTemplate_b94db74b948b95d437aa4da656eab639 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'hero_media' => [$this, 'block_hero_media'],
            'hero_content' => [$this, 'block_hero_content'],
            'hero_slot' => [$this, 'block_hero_slot'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--hero-billboard"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:hero-billboard"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:hero-billboard"));
        $context["hero_height"] = ((array_key_exists("height", $context)) ? (Twig\Extension\CoreExtension::default(($context["height"] ?? null), "full")) : ("full"));
        // line 2
        $context["hero_flex_position"] = ((array_key_exists("flex_position", $context)) ? (Twig\Extension\CoreExtension::default(($context["flex_position"] ?? null), "center-left")) : ("center-left"));
        // line 3
        $context["hero_overlay_opacity"] = ((array_key_exists("overlay_opacity", $context)) ? (Twig\Extension\CoreExtension::default(($context["overlay_opacity"] ?? null), "40%")) : ("40%"));
        // line 4
        $context["hero_object_position"] = ((array_key_exists("object_position", $context)) ? (Twig\Extension\CoreExtension::default(($context["object_position"] ?? null), "center")) : ("center"));
        // line 5
        $context["hero_overlap_navbar"] = (((($tmp = ((array_key_exists("overlap_navbar", $context)) ? (Twig\Extension\CoreExtension::default(($context["overlap_navbar"] ?? null), false)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 6
        $context["hero_content_background"] = (((($tmp = ((array_key_exists("content_background", $context)) ? (Twig\Extension\CoreExtension::default(($context["content_background"] ?? null), false)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 7
        yield "
";
        // line 9
        $context["additional_classes"] = ((array_key_exists("classes", $context)) ? (Twig\Extension\CoreExtension::default(($context["classes"] ?? null), "")) : (""));
        // line 10
        if (is_iterable(($context["additional_classes"] ?? null))) {
            // line 11
            yield "  ";
            $context["additional_classes"] = Twig\Extension\CoreExtension::join(($context["additional_classes"] ?? null), " ");
        }
        // line 13
        yield "
";
        // line 14
        $context["hero_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["relative flex flex-col"], ["height" => ["full" => "h-dvh", "large" => ["h-3/4 min-h-[600px] xl:min-h-[800px]"], "ribbon" => ["min-h-[300px] md:min-h-[400px] xl:min-h-[600px]"]], "flexPosition" => ["top-left" => "justify-start", "center-left" => "justify-center-safe", "bottom-left" => "justify-end", "hero-center" => "justify-center"], "overlapNavbar" => ["yes" => "mt-[calc(var(--navbar-height)*-1)]", "no" => ""]]);
        // line 36
        yield "
";
        // line 37
        $context["overlay_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["absolute inset-0 rounded-lg"], ["opacity" => ["0%" => "bg-black/0", "20%" => "bg-black/20", "40%" => "bg-black/40", "60%" => "bg-black/60", "75%" => "bg-black/75"]]);
        // line 51
        yield "
";
        // line 52
        $context["image_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["h-full w-full rounded-lg object-cover"], ["position" => ["top" => "object-top", "center" => "object-center", "bottom" => "object-bottom"]]);
        // line 64
        yield "
";
        // line 65
        $context["content_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["relative z-1 flex flex-col gap-6 p-4 md:p-6"], ["flexPosition" => ["top-left" => "", "center-left" => "", "bottom-left" => "", "hero-center" => ["items-center text-center lg:mx-auto"]], "overlapNavbar" => ["yes" => "", "no" => ""], "contentBackground" => ["yes" => "rounded-lg bg-white md:max-w-lg xl:max-w-xl", "no" => "lg:max-w-2/3"]]);
        // line 86
        yield "
<section
  class=\"";
        // line 88
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,         // line 89
($context["hero_variants"] ?? null), "apply", [["height" =>         // line 91
($context["hero_height"] ?? null), "flexPosition" =>         // line 92
($context["hero_flex_position"] ?? null), "overlapNavbar" =>         // line 93
($context["hero_overlap_navbar"] ?? null)],         // line 95
($context["additional_classes"] ?? null)], "method", false, false, true, 89), "html", null, true);
        // line 97
        yield "\"
>
  ";
        // line 99
        if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["media"] ?? null), "src", [], "any", false, false, true, 99))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 100
            yield "    <div class=\"absolute z-[-1] h-full w-full\">
      ";
            // line 101
            yield from $this->unwrap()->yieldBlock('hero_media', $context, $blocks);
            // line 122
            yield "    </div>
  ";
        }
        // line 124
        yield "  <div class=\"container mx-auto p-6 md:p-8\">
    <div
      class=\"";
        // line 126
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,         // line 127
($context["content_variants"] ?? null), "apply", [["flexPosition" =>         // line 128
($context["hero_flex_position"] ?? null), "overlapNavbar" =>         // line 129
($context["hero_overlap_navbar"] ?? null), "contentBackground" =>         // line 130
($context["hero_content_background"] ?? null)]], "method", false, false, true, 127), "html", null, true);
        // line 132
        yield "\"
    >
      ";
        // line 134
        yield from $this->unwrap()->yieldBlock('hero_content', $context, $blocks);
        // line 139
        yield "    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["height", "flex_position", "overlay_opacity", "object_position", "overlap_navbar", "content_background", "classes", "media"]);        yield from [];
    }

    // line 101
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_hero_media(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 102
        yield "        ";
        if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["media"] ?? null), "src", [], "any", false, false, true, 102))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 103
            yield "          <div
            class=\"";
            // line 104
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,             // line 105
($context["overlay_variants"] ?? null), "apply", [["opacity" =>             // line 106
($context["hero_overlay_opacity"] ?? null)]], "method", false, false, true, 105), "html", null, true);
            // line 108
            yield "\"
          ></div>
        ";
        }
        // line 111
        yield "        ";
        try {
            $_v0 = $this->load("canvas:image", 111);
        } catch (LoaderError $e) {
            // ignore missing template
            $_v0 = null;
        }
        if ($_v0) {
            yield from $_v0->unwrap()->yield(CoreExtension::toArray(["src" => CoreExtension::getAttribute($this->env, $this->source,             // line 112
($context["media"] ?? null), "src", [], "any", false, false, true, 112), "alt" => CoreExtension::getAttribute($this->env, $this->source,             // line 113
($context["media"] ?? null), "alt", [], "any", false, false, true, 113), "width" => CoreExtension::getAttribute($this->env, $this->source,             // line 114
($context["media"] ?? null), "width", [], "any", false, false, true, 114), "height" => CoreExtension::getAttribute($this->env, $this->source,             // line 115
($context["media"] ?? null), "height", [], "any", false, false, true, 115), "loading" => "eager", "class" => CoreExtension::getAttribute($this->env, $this->source,             // line 117
($context["image_variants"] ?? null), "apply", [["position" =>             // line 118
($context["hero_object_position"] ?? null)]], "method", false, false, true, 117)]));
        }
        // line 121
        yield "      ";
        yield from [];
    }

    // line 134
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_hero_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 135
        yield "        ";
        yield from $this->unwrap()->yieldBlock('hero_slot', $context, $blocks);
        // line 138
        yield "      ";
        yield from [];
    }

    // line 135
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_hero_slot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 136
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:hero-billboard";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  210 => 136,  203 => 135,  198 => 138,  195 => 135,  188 => 134,  183 => 121,  180 => 118,  179 => 117,  178 => 115,  177 => 114,  176 => 113,  175 => 112,  166 => 111,  161 => 108,  159 => 106,  158 => 105,  157 => 104,  154 => 103,  151 => 102,  144 => 101,  135 => 139,  133 => 134,  129 => 132,  127 => 130,  126 => 129,  125 => 128,  124 => 127,  123 => 126,  119 => 124,  115 => 122,  113 => 101,  110 => 100,  108 => 99,  104 => 97,  102 => 95,  101 => 93,  100 => 92,  99 => 91,  98 => 89,  97 => 88,  93 => 86,  91 => 65,  88 => 64,  86 => 52,  83 => 51,  81 => 37,  78 => 36,  76 => 14,  73 => 13,  69 => 11,  67 => 10,  65 => 9,  62 => 7,  60 => 6,  58 => 5,  56 => 4,  54 => 3,  52 => 2,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:hero-billboard", "themes/contrib/haven_theme/components/hero-billboard/hero-billboard.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "if" => 10, "block" => 101, "include" => 111];
        static $filters = ["default" => 1, "join" => 11, "escape" => 89];
        static $functions = ["html_cva" => 15];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['default', 'join', 'escape'],
                ['html_cva'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
