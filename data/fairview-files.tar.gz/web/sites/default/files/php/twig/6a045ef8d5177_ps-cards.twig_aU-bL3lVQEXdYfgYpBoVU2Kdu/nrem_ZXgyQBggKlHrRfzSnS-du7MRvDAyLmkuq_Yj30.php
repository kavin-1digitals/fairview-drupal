<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/provider-search/ps-cards.twig */
class __TwigTemplate_3c5f4dce769855e1806fdca2ae9566b0 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<div class=\"ps-results\">
  <div class=\"ps-results__meta\">
    <p class=\"ps-results__count\">";
        // line 6
        if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
            if (\array_key_exists("canvas_slot_ids", $context) && \in_array("results_summary", $context["canvas_slot_ids"], TRUE)) {
                yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "results_summary");
            } else {
                yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "results_summary");
            }
        }
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["results_summary"] ?? null), "html", null, true);
        if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
            if (\array_key_exists("canvas_slot_ids", $context) && \in_array("results_summary", $context["canvas_slot_ids"], TRUE)) {
                yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "results_summary");
            } else {
                yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "results_summary");
            }
        }
        yield "</p>
    <nav class=\"ps-results__sort\" aria-label=\"";
        // line 7
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Sort results"));
        yield "\">
      <a href=\"#\" class=\"ps-results__sort-link is-active\">";
        // line 8
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Best Match"));
        yield "</a>
      <span class=\"ps-results__sep\" aria-hidden=\"true\">|</span>
      <a href=\"#\" class=\"ps-results__sort-link\">";
        // line 10
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Availability"));
        yield "</a>
      <span class=\"ps-results__sep\" aria-hidden=\"true\">|</span>
      <a href=\"#\" class=\"ps-results__sort-link\">";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("A-Z"));
        yield "</a>
      <span class=\"ps-results__sep\" aria-hidden=\"true\">|</span>
      <a href=\"#\" class=\"ps-results__sort-link\">";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Z-A"));
        yield "</a>
    </nav>
  </div>

  <ul class=\"ps-cards\" role=\"list\">
    ";
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["providers"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 20
            yield "      <li class=\"ps-card\">
        <div class=\"ps-card__media\">
          <div class=\"ps-card__avatar ps-card__avatar--tone-";
            // line 22
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((CoreExtension::getAttribute($this->env, $this->source, $context["p"], "avatar_tone", [], "any", true, true, true, 22)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["p"], "avatar_tone", [], "any", false, false, true, 22), 0)) : (0)), "html", null, true);
            yield "\" aria-hidden=\"true\">
            <span class=\"ps-card__avatar-text\">";
            // line 23
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((CoreExtension::getAttribute($this->env, $this->source, $context["p"], "initials", [], "any", true, true, true, 23)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["p"], "initials", [], "any", false, false, true, 23), "?")) : ("?")), "html", null, true);
            yield "</span>
          </div>
        </div>
        <div class=\"ps-card__main\">
          <h3 class=\"ps-card__name\">";
            // line 27
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["p"], "name", [], "any", false, false, true, 27), "html", null, true);
            yield "</h3>
          <p class=\"ps-card__spec\">";
            // line 28
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["p"], "specialties", [], "any", false, false, true, 28), "html", null, true);
            yield "</p>
          ";
            // line 29
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["p"], "badge", [], "any", false, false, true, 29)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 30
                yield "            <p class=\"ps-card__badge\">";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["p"], "badge", [], "any", false, false, true, 30), "html", null, true);
                yield "</p>
          ";
            }
            // line 32
            yield "          <p class=\"ps-card__clinic\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["p"], "clinic", [], "any", false, false, true, 32), "html", null, true);
            yield "</p>
          <p class=\"ps-card__addr\">";
            // line 33
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["p"], "address", [], "any", false, false, true, 33), "html", null, true);
            yield "</p>
          <p class=\"ps-card__contact\">
            <a href=\"#\" class=\"ps-card__inline-link\">";
            // line 35
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Map"));
            yield "</a>
            <span class=\"ps-card__dot\" aria-hidden=\"true\">·</span>
            <a href=\"tel:";
            // line 37
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, Twig\Extension\CoreExtension::replace(CoreExtension::getAttribute($this->env, $this->source, $context["p"], "phone", [], "any", false, false, true, 37), [" " => "", "-" => "", "(" => "", ")" => ""]), "html", null, true);
            yield "\" class=\"ps-card__inline-link\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["p"], "phone", [], "any", false, false, true, 37), "html", null, true);
            yield "</a>
          </p>
          ";
            // line 39
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["p"], "more_locations", [], "any", false, false, true, 39)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 40
                yield "            <p class=\"ps-card__more\"><a href=\"#\" class=\"ps-card__link\">";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["p"], "more_locations", [], "any", false, false, true, 40), "html", null, true);
                yield "</a></p>
          ";
            }
            // line 42
            yield "          <p class=\"ps-card__cta\">
            <a href=\"#\" class=\"ps-card__btn\">";
            // line 43
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Schedule a Visit"));
            yield "</a>
          </p>
        </div>
      </li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['p'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        yield "  </ul>

  <nav class=\"ps-pagination\" aria-label=\"";
        // line 50
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Pagination"));
        yield "\">
    <a href=\"#\" class=\"ps-pagination__link ps-pagination__link--nav\" aria-disabled=\"true\">";
        // line 51
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Previous"));
        yield "</a>
    <ol class=\"ps-pagination__list\">
      <li><a href=\"#\" class=\"ps-pagination__num is-current\" aria-current=\"page\">1</a></li>
      <li><a href=\"#\" class=\"ps-pagination__num\">2</a></li>
      <li><a href=\"#\" class=\"ps-pagination__num\">3</a></li>
      <li><span class=\"ps-pagination__ellipsis\">&hellip;</span></li>
      <li><a href=\"#\" class=\"ps-pagination__num\">120</a></li>
    </ol>
    <a href=\"#\" class=\"ps-pagination__link ps-pagination__link--nav\">";
        // line 59
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Next"));
        yield "</a>
  </nav>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["results_summary", "providers"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/provider-search/ps-cards.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  191 => 59,  180 => 51,  176 => 50,  172 => 48,  161 => 43,  158 => 42,  152 => 40,  150 => 39,  143 => 37,  138 => 35,  133 => 33,  128 => 32,  122 => 30,  120 => 29,  116 => 28,  112 => 27,  105 => 23,  101 => 22,  97 => 20,  93 => 19,  85 => 14,  80 => 12,  75 => 10,  70 => 8,  66 => 7,  48 => 6,  44 => 4,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/provider-search/ps-cards.twig", "/var/www/html/web/themes/custom/fairview/components/provider-search/ps-cards.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 19, "if" => 29];
        static $filters = ["escape" => 6, "t" => 7, "default" => 22, "replace" => 37];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if'],
                ['escape', 't', 'default', 'replace'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
