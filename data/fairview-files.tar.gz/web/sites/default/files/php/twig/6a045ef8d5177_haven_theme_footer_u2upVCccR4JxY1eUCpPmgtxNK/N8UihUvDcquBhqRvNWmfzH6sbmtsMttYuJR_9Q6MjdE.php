<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:footer */
class __TwigTemplate_920fbf305b850f7d2c0d2f884367267d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'footer_first' => [$this, 'block_footer_first'],
            'footer_last' => [$this, 'block_footer_last'],
            'footer_utility_first' => [$this, 'block_footer_utility_first'],
            'footer_utility_last' => [$this, 'block_footer_utility_last'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--footer"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:footer"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:footer"));
        // line 2
        $context["additional_classes"] = ((array_key_exists("footer_classes", $context)) ? (Twig\Extension\CoreExtension::default(($context["footer_classes"] ?? null), "")) : (""));
        // line 3
        if (is_iterable(($context["additional_classes"] ?? null))) {
            // line 4
            yield "  ";
            $context["additional_classes"] = Twig\Extension\CoreExtension::join(($context["additional_classes"] ?? null), " ");
        }
        // line 6
        yield "
";
        // line 7
        $context["footer_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["flex", "flex-col"]);
        // line 8
        yield "
";
        // line 9
        $context["footer_top_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["flex w-full flex-col justify-between gap-6 py-10 md:grid md:grid-cols-2 md:gap-6 [&_li]:text-lg"]);
        // line 10
        yield "
";
        // line 11
        $context["footer_first_col_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["flex", "flex-col", "gap-6", "[&_.branding]:h-8"]);
        // line 12
        yield "
";
        // line 13
        $context["footer_last_col_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["flex flex-col gap-2 md:mx-0 md:ms-auto md:w-xs lg:w-md", "[&_form]:flex [&_form]:flex-row [&_form]:gap-[1px] md:[&_form]:items-end", "[&_input]:bg-background [&_input:focus]:bg-primary-foreground", "[&_input[type=\"email\"]]:rounded-l-full [&_input[type=\"text\"]]:rounded-l-full", "[&_input[type=\"email\"]]:pl-4 [&_input[type=\"text\"]]:pl-4", "[&_input[type=\"email\"]]:border-none [&_input[type=\"text\"]]:border-none", "[&_input[type=\"submit\"]]:rounded-l-none [&_input[type=\"submit\"]]:bg-accent [&_input[type=\"submit\"]]:text-primary", "[&_input[type=\"submit\"]:focus-visible]:bg-accent-dark [&_input[type=\"submit\"]:hover]:bg-accent-dark"]);
        // line 27
        yield "
";
        // line 28
        $context["footer_bottom_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["flex w-full flex-col gap-2 py-3 [&_li]:text-xs [&_li]:md:text-sm [&_li]:xl:text-md", "md:grid md:grid-cols-[minmax(0,2fr)_minmax(0,1fr)] md:gap-6 md:py-4", "border-t border-input"]);
        // line 37
        yield "
";
        // line 38
        $context["footer_bottom_col_variants"] = Twig\Extra\Html\HtmlExtension::htmlCva(["site-footer--bottom-col"], ["align" => ["left" => "", "right" => ["md:flex md:justify-end"]]]);
        // line 49
        yield "
<section class=\"site-footer -mt-6 bg-primary text-primary-foreground\">
  <div class=\"container mx-auto px-4 pt-6 md:px-12 ";
        // line 51
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["footer_variants"] ?? null), "apply", [[], ($context["additional_classes"] ?? null)], "method", false, false, true, 51), "html", null, true);
        yield "\">
    <div class=\"";
        // line 52
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["footer_top_variants"] ?? null), "apply", [[]], "method", false, false, true, 52), "html", null, true);
        yield "\">
      ";
        // line 53
        if (        $this->unwrap()->hasBlock("footer_first", $context, $blocks)) {
            // line 54
            yield "        <div class=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["footer_first_col_variants"] ?? null), "apply", [[]], "method", false, false, true, 54), "html", null, true);
            yield "\">
          ";
            // line 55
            yield from $this->unwrap()->yieldBlock('footer_first', $context, $blocks);
            // line 58
            yield "        </div>
      ";
        }
        // line 60
        yield "
      ";
        // line 61
        if (        $this->unwrap()->hasBlock("footer_last", $context, $blocks)) {
            // line 62
            yield "        <div class=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["footer_last_col_variants"] ?? null), "apply", [[]], "method", false, false, true, 62), "html", null, true);
            yield "\">
          ";
            // line 63
            yield from $this->unwrap()->yieldBlock('footer_last', $context, $blocks);
            // line 66
            yield "        </div>
      ";
        }
        // line 68
        yield "    </div>

    <div class=\"";
        // line 70
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["footer_bottom_variants"] ?? null), "apply", [[]], "method", false, false, true, 70), "html", null, true);
        yield "\">
      ";
        // line 71
        if (        $this->unwrap()->hasBlock("footer_utility_first", $context, $blocks)) {
            // line 72
            yield "        <div
          class=\"";
            // line 73
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,             // line 74
($context["footer_bottom_col_variants"] ?? null), "apply", [["align" => "left"]], "method", false, false, true, 74), "html", null, true);
            // line 77
            yield "\"
        >
          ";
            // line 79
            yield from $this->unwrap()->yieldBlock('footer_utility_first', $context, $blocks);
            // line 82
            yield "        </div>
      ";
        }
        // line 84
        yield "
      ";
        // line 85
        if (        $this->unwrap()->hasBlock("footer_utility_last", $context, $blocks)) {
            // line 86
            yield "        <div
          class=\"";
            // line 87
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,             // line 88
($context["footer_bottom_col_variants"] ?? null), "apply", [["align" => "right"]], "method", false, false, true, 88), "html", null, true);
            // line 91
            yield "\"
        >
          ";
            // line 93
            yield from $this->unwrap()->yieldBlock('footer_utility_last', $context, $blocks);
            // line 96
            yield "        </div>
      ";
        }
        // line 98
        yield "    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["footer_classes"]);        yield from [];
    }

    // line 55
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_first(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 56
        yield "            ";
        // line 57
        yield "          ";
        yield from [];
    }

    // line 63
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_last(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 64
        yield "            ";
        // line 65
        yield "          ";
        yield from [];
    }

    // line 79
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_utility_first(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 80
        yield "            ";
        // line 81
        yield "          ";
        yield from [];
    }

    // line 93
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_utility_last(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 94
        yield "            ";
        // line 95
        yield "          ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:footer";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  238 => 95,  236 => 94,  229 => 93,  224 => 81,  222 => 80,  215 => 79,  210 => 65,  208 => 64,  201 => 63,  196 => 57,  194 => 56,  187 => 55,  178 => 98,  174 => 96,  172 => 93,  168 => 91,  166 => 88,  165 => 87,  162 => 86,  160 => 85,  157 => 84,  153 => 82,  151 => 79,  147 => 77,  145 => 74,  144 => 73,  141 => 72,  139 => 71,  135 => 70,  131 => 68,  127 => 66,  125 => 63,  120 => 62,  118 => 61,  115 => 60,  111 => 58,  109 => 55,  104 => 54,  102 => 53,  98 => 52,  94 => 51,  90 => 49,  88 => 38,  85 => 37,  83 => 28,  80 => 27,  78 => 13,  75 => 12,  73 => 11,  70 => 10,  68 => 9,  65 => 8,  63 => 7,  60 => 6,  56 => 4,  54 => 3,  52 => 2,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:footer", "themes/contrib/haven_theme/components/footer/footer.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 2, "if" => 3, "block" => 55];
        static $filters = ["default" => 2, "join" => 4, "escape" => 51];
        static $functions = ["html_cva" => 7];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block'],
                ['default', 'join', 'escape'],
                ['html_cva'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
