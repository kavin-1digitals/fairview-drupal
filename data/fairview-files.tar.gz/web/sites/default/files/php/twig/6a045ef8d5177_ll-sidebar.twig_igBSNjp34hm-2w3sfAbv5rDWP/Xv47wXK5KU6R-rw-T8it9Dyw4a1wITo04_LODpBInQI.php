<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/location-list/ll-sidebar.twig */
class __TwigTemplate_625ed0080ec4befcb675c1b6db0dee72 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<aside class=\"ll-sidebar\" aria-labelledby=\"ll-filters-title\">
  <h2 id=\"ll-filters-title\" class=\"ll-sidebar__title\">";
        // line 5
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Filters"));
        yield "</h2>

  <div class=\"ll-filter-block\">
    <label class=\"ll-switch\">
      <input type=\"checkbox\" name=\"open_only\" class=\"ll-switch__input\" data-ll-filter=\"open\" data-ll-filter-label=\"";
        // line 9
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Show Open Locations Only"));
        yield "\" />
      <span class=\"ll-switch__track\" aria-hidden=\"true\"></span>
      <span class=\"ll-switch__text\">";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Show Open Locations Only"));
        yield "</span>
    </label>
  </div>

  <fieldset class=\"ll-filter-block\">
    <legend class=\"ll-filter-legend\">";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Location Types"));
        yield "</legend>
    ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("ll_filter_location_types", $context)) ? (Twig\Extension\CoreExtension::default(($context["ll_filter_location_types"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["opt"]) {
            // line 18
            yield "      <label class=\"ll-check\">
        <input type=\"checkbox\" name=\"loc_type[]\" value=\"";
            // line 19
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "id", [], "any", false, false, true, 19), "html", null, true);
            yield "\" data-ll-filter=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "id", [], "any", false, false, true, 19), "html", null, true);
            yield "\" data-ll-filter-label=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "label", [], "any", false, false, true, 19), "html", null, true);
            yield "\" />
        <span>";
            // line 20
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "label", [], "any", false, false, true, 20), "html", null, true);
            yield "</span>
      </label>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['opt'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        yield "  </fieldset>

  <fieldset class=\"ll-filter-block\">
    <legend class=\"ll-filter-legend\">";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Departments (15)"));
        yield "</legend>
    ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("ll_filter_departments", $context)) ? (Twig\Extension\CoreExtension::default(($context["ll_filter_departments"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["opt"]) {
            // line 28
            yield "      <label class=\"ll-check\">
        <input type=\"checkbox\" name=\"dept[]\" value=\"";
            // line 29
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "id", [], "any", false, false, true, 29), "html", null, true);
            yield "\" data-ll-filter=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "id", [], "any", false, false, true, 29), "html", null, true);
            yield "\" data-ll-filter-label=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "label", [], "any", false, false, true, 29), "html", null, true);
            yield "\" />
        <span>";
            // line 30
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "label", [], "any", false, false, true, 30), "html", null, true);
            yield "</span>
      </label>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['opt'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        yield "  </fieldset>

  <fieldset class=\"ll-filter-block\">
    <legend class=\"ll-filter-legend\">";
        // line 36
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Amenities (13)"));
        yield "</legend>
    <div class=\"ll-filter-scroll\">
      ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("ll_filter_amenities", $context)) ? (Twig\Extension\CoreExtension::default(($context["ll_filter_amenities"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["opt"]) {
            // line 39
            yield "        <label class=\"ll-check\">
          <input type=\"checkbox\" name=\"amen[]\" value=\"";
            // line 40
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "id", [], "any", false, false, true, 40), "html", null, true);
            yield "\" data-ll-filter=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "id", [], "any", false, false, true, 40), "html", null, true);
            yield "\" data-ll-filter-label=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "label", [], "any", false, false, true, 40), "html", null, true);
            yield "\" />
          <span>";
            // line 41
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "label", [], "any", false, false, true, 41), "html", null, true);
            yield "</span>
        </label>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['opt'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        yield "    </div>
  </fieldset>

  <fieldset class=\"ll-filter-block\">
    <legend class=\"ll-filter-legend\">";
        // line 48
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Location Services (22)"));
        yield "</legend>
    <div class=\"ll-filter-scroll ll-filter-scroll--tall\">
      ";
        // line 50
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("ll_filter_services", $context)) ? (Twig\Extension\CoreExtension::default(($context["ll_filter_services"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["opt"]) {
            // line 51
            yield "        <label class=\"ll-check\">
          <input type=\"checkbox\" name=\"svc[]\" value=\"";
            // line 52
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "id", [], "any", false, false, true, 52), "html", null, true);
            yield "\" data-ll-filter=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "id", [], "any", false, false, true, 52), "html", null, true);
            yield "\" data-ll-filter-label=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "label", [], "any", false, false, true, 52), "html", null, true);
            yield "\" />
          <span>";
            // line 53
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["opt"], "label", [], "any", false, false, true, 53), "html", null, true);
            yield "</span>
        </label>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['opt'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 56
        yield "    </div>
  </fieldset>
</aside>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["ll_filter_location_types", "ll_filter_departments", "ll_filter_amenities", "ll_filter_services"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/location-list/ll-sidebar.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  197 => 56,  188 => 53,  180 => 52,  177 => 51,  173 => 50,  168 => 48,  162 => 44,  153 => 41,  145 => 40,  142 => 39,  138 => 38,  133 => 36,  128 => 33,  119 => 30,  111 => 29,  108 => 28,  104 => 27,  100 => 26,  95 => 23,  86 => 20,  78 => 19,  75 => 18,  71 => 17,  67 => 16,  59 => 11,  54 => 9,  47 => 5,  44 => 4,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/location-list/ll-sidebar.twig", "/var/www/html/web/themes/custom/fairview/components/location-list/ll-sidebar.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 17];
        static $filters = ["t" => 5, "default" => 17, "escape" => 19];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['t', 'default', 'escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
