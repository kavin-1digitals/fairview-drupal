<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:text */
class __TwigTemplate_59bd22b18fcaad3fa59e15107621dfbf extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--text"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:text"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:text"));
        // line 2
        $context["text_text_color"] = ((array_key_exists("text_color", $context)) ? (Twig\Extension\CoreExtension::default(($context["text_color"] ?? null), "default")) : ("default"));
        // line 3
        $context["text_text_size"] = ((array_key_exists("text_size", $context)) ? (Twig\Extension\CoreExtension::default(($context["text_size"] ?? null), "normal")) : ("normal"));
        // line 4
        $context["column_count"] = ((array_key_exists("columns", $context)) ? (Twig\Extension\CoreExtension::default(($context["columns"] ?? null), "1 column")) : ("1 column"));
        // line 5
        yield "
";
        // line 6
        $context["text_component"] = Twig\Extra\Html\HtmlExtension::htmlCva(["font-serif", "[&_h2]:mt-6 [&_h2]:mb-3 [&_h3]:mt-4 [&_h3]:mb-2 [&_h4]:mt-3 [&_h4]:mb-1 [&_h5]:my-2 [&_h6]:my-1", "[&_h2]:text-2xl [&_h2]:lg:text-3xl [&_h3]:text-xl [&_h3]:lg:text-2xl [&_h4]:text-lg [&_h4]:lg:text-xl", "[&_li]:mb-1 [&_ol]:my-4 [&_ol]:list-decimal [&_ul]:my-4", "[&>*:first-child]:mt-0 [&>*:last-child]:mb-0", "[&_a]:underline [&_a]:underline-offset-2 [&_a]:transition [&_a]:duration-300", "[&_table]:my-6", "[&_td]:p-3 [&_th]:p-3", "[&_tr]:border-b [&_tr]:border-b-border/40", "[&_blockquote]:xl:3xl [&_blockquote]:text-xl [&_blockquote]:italic [&_blockquote]:md:text-2xl", "[&_blockquote]:m-auto [&_blockquote]:max-w-3xl [&_blockquote]:[&>*:last-child]:mb-0", "[&_blockquote]:my-8 [&_blockquote]:border-l-4 [&_blockquote]:border-border/40 [&_blockquote]:py-1.5 [&_blockquote]:pl-4", "[&_figure]:my-6 [&_figure]:w-fit", "[&_div.align-center]:my-6 [&_div.align-center]:w-fit", "[&_figcaption]:block [&_figcaption]:pt-2 [&_figcaption]:pb-3 [&_figcaption]:text-sm [&_figcaption]:opacity-80 [&_figcaption]:lg:text-base"], ["textColor" => ["default" => "text-foreground [&_a]:hover:text-foreground/70", "inverted" => "text-background [&_a]:hover:text-background/70", "primary" => "text-primary [&_a]:hover:text-primary/70"], "textSize" => ["text-xs" => "text-xs md:text-sm xl:text-md", "text-sm" => "text-sm md:text-md xl:text-lg", "normal" => "text-base md:text-lg xl:text-xl", "text-lg" => "text-lg md:text-xl xl:text-2xl", "text-xl" => "text-xl md:text-2xl xl:text-3xl", "text-2xl" => "text-2xl md:text-3xl xl:text-4xl", "text-3xl" => "text-3xl md:text-4xl xl:text-5xl"], "columns" => ["1 column" => "", "2 columns" => "sm:columns-2", "3 columns" => "sm:columns-3"]]);
        // line 48
        yield "
";
        // line 49
        $context["text_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 50
($context["text_component"] ?? null), "apply", [["textColor" =>         // line 51
($context["text_text_color"] ?? null), "textSize" =>         // line 52
($context["text_text_size"] ?? null), "columns" =>         // line 53
($context["column_count"] ?? null)]], "method", false, false, true, 50);
        // line 56
        yield "
<div class=\"";
        // line 57
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["text_classes"] ?? null), "html", null, true);
        yield "\">
  ";
        // line 58
        if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
            if (\array_key_exists("canvas_slot_ids", $context) && \in_array("text", $context["canvas_slot_ids"], TRUE)) {
                yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "text");
            } else {
                yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "text");
            }
        }
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["text"] ?? null), "html", null, true);
        if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
            if (\array_key_exists("canvas_slot_ids", $context) && \in_array("text", $context["canvas_slot_ids"], TRUE)) {
                yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "text");
            } else {
                yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "text");
            }
        }
        yield "
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["text_color", "text_size", "columns", "text"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:text";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  75 => 58,  71 => 57,  68 => 56,  66 => 53,  65 => 52,  64 => 51,  63 => 50,  62 => 49,  59 => 48,  57 => 6,  54 => 5,  52 => 4,  50 => 3,  48 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:text", "themes/contrib/haven_theme/components/text/text.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 2];
        static $filters = ["default" => 2, "escape" => 57];
        static $functions = ["html_cva" => 7];

        try {
            $this->sandbox->checkSecurity(
                ['set'],
                ['default', 'escape'],
                ['html_cva'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
