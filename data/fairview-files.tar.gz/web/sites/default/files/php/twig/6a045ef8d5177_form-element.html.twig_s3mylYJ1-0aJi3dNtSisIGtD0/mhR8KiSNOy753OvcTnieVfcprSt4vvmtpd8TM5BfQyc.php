<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* modules/contrib/canvas/themes/canvas_stark/templates/form/form-element.html.twig */
class __TwigTemplate_b5e5cf9dc740784834d664da6a154a09 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 49
        yield "
<drupal-canvas-form-element
    attributes=\"";
        // line 51
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->jsxAttributes(($context["attributes"] ?? null)), "html", null, true);
        yield "\"
    errors=\"";
        // line 52
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(($context["errors"] ?? null)), "html", null, true);
        yield "\"
    prefix=\"";
        // line 53
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->jsxAttributes(($context["prefix"] ?? null)), "html", null, true);
        yield "\"
    suffix=\"";
        // line 54
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->jsxAttributes(($context["suffix"] ?? null)), "html", null, true);
        yield "\"
    required=\"";
        // line 55
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->jsxAttributes(($context["required"] ?? null)), "html", null, true);
        yield "\"
    label-display=\"";
        // line 56
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->jsxAttributes(($context["label_display"] ?? null)), "html", null, true);
        yield "\"
    title-display=\"";
        // line 57
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->jsxAttributes(($context["title_display"] ?? null)), "html", null, true);
        yield "\"
    description-display=\"";
        // line 58
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->jsxAttributes(($context["description_display"] ?? null)), "html", null, true);
        yield "\"
    type=\"";
        // line 59
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->jsxAttributes(($context["type"] ?? null)), "html", null, true);
        yield "\"
    name=\"";
        // line 60
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->jsxAttributes(($context["name"] ?? null)), "html", null, true);
        yield "\"
    description-attributes=\"";
        // line 61
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, ($context["description"] ?? null), "attributes", [], "any", false, false, true, 61), "html", null, true);
        yield "\"
    description=\"";
        // line 62
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(CoreExtension::getAttribute($this->env, $this->source, ($context["description"] ?? null), "content", [], "any", false, false, true, 62)), "html_attr");
        yield "\"
    disabled=\"";
        // line 63
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->jsxAttributes(($context["disabled"] ?? null)), "html", null, true);
        yield "\"
>
  ";
        // line 65
        if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
            if (\array_key_exists("canvas_slot_ids", $context) && \in_array("children", $context["canvas_slot_ids"], TRUE)) {
                yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "children");
            } else {
                yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "children");
            }
        }
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["children"] ?? null), "html", null, true);
        if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
            if (\array_key_exists("canvas_slot_ids", $context) && \in_array("children", $context["canvas_slot_ids"], TRUE)) {
                yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "children");
            } else {
                yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "children");
            }
        }
        yield "
  ";
        // line 66
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\canvas\Twig\CanvasTwigExtension']->slot("label", ($context["label"] ?? null)));
        yield "
</drupal-canvas-form-element>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["attributes", "errors", "prefix", "suffix", "required", "label_display", "title_display", "description_display", "type", "name", "description", "disabled", "children", "label"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "modules/contrib/canvas/themes/canvas_stark/templates/form/form-element.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  119 => 66,  101 => 65,  96 => 63,  92 => 62,  88 => 61,  84 => 60,  80 => 59,  76 => 58,  72 => 57,  68 => 56,  64 => 55,  60 => 54,  56 => 53,  52 => 52,  48 => 51,  44 => 49,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "modules/contrib/canvas/themes/canvas_stark/templates/form/form-element.html.twig", "/var/www/html/web/modules/contrib/canvas/themes/canvas_stark/templates/form/form-element.html.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["escape" => 51, "jsx_attributes" => 51, "e" => 62];
        static $functions = ["render_var" => 52, "slot" => 66];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape', 'jsx_attributes', 'e'],
                ['render_var', 'slot'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
