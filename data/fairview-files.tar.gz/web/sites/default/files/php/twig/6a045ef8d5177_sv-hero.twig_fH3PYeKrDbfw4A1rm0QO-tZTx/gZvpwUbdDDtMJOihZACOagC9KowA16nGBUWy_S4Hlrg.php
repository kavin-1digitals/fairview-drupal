<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/services/sv-hero.twig */
class __TwigTemplate_6931af6a69001611bbd48bf435d86bac extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"sv-hero\" aria-labelledby=\"sv-hero-title\">
  <div class=\"sv-hero__inner\">
    <div class=\"sv-hero__left\">
      <h1 id=\"sv-hero-title\" class=\"sv-hero__title\">";
        // line 10
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_hero_title", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_hero_title"] ?? null), "")) : ("")), "html", null, true);
        yield "</h1>
      <p class=\"sv-hero__subtitle\">";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_hero_subtitle", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_hero_subtitle"] ?? null), "")) : ("")), "html", null, true);
        yield "</p>
      <form class=\"sv-hero__search\" role=\"search\" action=\"/services\" method=\"get\">
        <label class=\"sv-hero__search-label\" for=\"sv-service-search\">";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_search_info", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_search_info"] ?? null), "")) : ("")), "html", null, true);
        yield "</label>
        <div class=\"sv-hero__search-row\">
          <input id=\"sv-service-search\" class=\"sv-hero__input\" type=\"search\" name=\"q\" placeholder=\"";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_search_hint", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_search_hint"] ?? null), "")) : ("")), "html", null, true);
        yield "\" autocomplete=\"off\" />
          <button type=\"submit\" class=\"sv-hero__submit\" aria-label=\"";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Search"));
        yield "\">
            <span aria-hidden=\"true\">→</span>
          </button>
        </div>
      </form>
      <p class=\"sv-hero__all-wrap\">
        <a class=\"sv-hero__all-link\" href=\"";
        // line 22
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_view_all_services_url", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_view_all_services_url"] ?? null), "#")) : ("#")), "html", null, true);
        yield "\">";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("View All Services"));
        yield "</a>
      </p>
      <p class=\"sv-hero__helper\">
        ";
        // line 25
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Don't know which care type to choose?"));
        yield "
        <a class=\"sv-hero__helper-link\" href=\"";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_symptom_checker_url", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_symptom_checker_url"] ?? null), "#")) : ("#")), "html", null, true);
        yield "\">";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Try Symptom Checker"));
        yield "</a>
      </p>
    </div>
    <div class=\"sv-hero__right\">
      <h2 class=\"sv-browse__title\">";
        // line 30
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Browse By"));
        yield "</h2>
      <ul class=\"sv-browse__grid\">
        ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("sv_browse_cards", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_browse_cards"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["card"]) {
            // line 33
            yield "          <li class=\"sv-browse__cell\">
            <a class=\"sv-browse-card\" href=\"";
            // line 34
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((CoreExtension::getAttribute($this->env, $this->source, $context["card"], "url", [], "any", true, true, true, 34)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["card"], "url", [], "any", false, false, true, 34), "#")) : ("#")), "html", null, true);
            yield "\">
              <span class=\"sv-browse-card__icon-wrap\" aria-hidden=\"true\">
                ";
            // line 36
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["card"], "icon", [], "any", false, false, true, 36)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 37
                yield "                  <img class=\"sv-browse-card__icon\" src=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_img_base", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_img_base"] ?? null), "")) : ("")), "html", null, true);
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["card"], "icon", [], "any", false, false, true, 37), "html", null, true);
                yield "\" width=\"48\" height=\"48\" alt=\"\" loading=\"lazy\" />
                ";
            }
            // line 39
            yield "              </span>
              <span class=\"sv-browse-card__label\">";
            // line 40
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["card"], "label", [], "any", false, false, true, 40), "html", null, true);
            yield "</span>
            </a>
          </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['card'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        yield "      </ul>
    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["sv_hero_title", "sv_hero_subtitle", "sv_search_info", "sv_search_hint", "sv_view_all_services_url", "sv_symptom_checker_url", "sv_browse_cards", "sv_img_base"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/services/sv-hero.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  136 => 44,  126 => 40,  123 => 39,  116 => 37,  114 => 36,  109 => 34,  106 => 33,  102 => 32,  97 => 30,  88 => 26,  84 => 25,  76 => 22,  67 => 16,  63 => 15,  58 => 13,  53 => 11,  49 => 10,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/services/sv-hero.twig", "/var/www/html/web/themes/custom/fairview/components/services/sv-hero.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 32, "if" => 36];
        static $filters = ["escape" => 10, "default" => 10, "t" => 16];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if'],
                ['escape', 'default', 't'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
