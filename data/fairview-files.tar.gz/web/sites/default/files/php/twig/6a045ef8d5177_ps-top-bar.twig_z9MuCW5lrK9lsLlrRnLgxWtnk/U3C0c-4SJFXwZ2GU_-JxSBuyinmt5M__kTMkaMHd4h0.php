<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/provider-search/ps-top-bar.twig */
class __TwigTemplate_14f7c01479eba05c8c06f7c8a78618a7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<section class=\"ps-top\" aria-labelledby=\"ps-search-heading\">
  <div class=\"ps-top__inner\">
    <h1 id=\"ps-search-heading\" class=\"ps-top__heading\">";
        // line 6
        yield ((($context["search_heading"] ?? null)) ? ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $context["search_heading"], "html", null, true)) : ("What can we help you with?"));
        yield "</h1>
    <form class=\"ps-top__form\" role=\"search\" action=\"/search\" method=\"get\" id=\"ps-provider-search-form\">
      <label for=\"ps-query\" class=\"visually-hidden\">";
        // line 8
        yield ((($context["search_heading"] ?? null)) ? ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $context["search_heading"], "html", null, true)) : ("What can we help you with?"));
        yield "</label>
      <div class=\"ps-top__field\">
        <input type=\"search\" id=\"ps-query\" name=\"q\" class=\"ps-top__input\" placeholder=\"";
        // line 10
        yield ((($context["search_hint"] ?? null)) ? ($this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, $context["search_hint"], "html", null, true)) : ("Enter a Condition, Specility or Provider Name"));
        yield "\" autocomplete=\"off\" />
      </div>
      <button type=\"submit\" class=\"ps-top__submit\">";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Search"));
        yield "</button>
    </form>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["search_heading", "search_hint"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/provider-search/ps-top-bar.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  63 => 12,  58 => 10,  53 => 8,  48 => 6,  44 => 4,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/provider-search/ps-top-bar.twig", "/var/www/html/web/themes/custom/fairview/components/provider-search/ps-top-bar.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["escape" => 6, "t" => 12];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['escape', 't'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
