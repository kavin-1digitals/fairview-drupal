<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:navbar */
class __TwigTemplate_d9ee3a03c9b9c3a9400f915084526488 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'logo' => [$this, 'block_logo'],
            'navigation' => [$this, 'block_navigation'],
            'links' => [$this, 'block_links'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--navbar"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:navbar"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:navbar"));
        $context["dropdown_menu"] = Twig\Extra\Html\HtmlExtension::htmlCva(["navbar--dropdown-menu", "flex max-h-full flex-col items-stretch justify-start gap-2 md:flex-row", "overflow-auto md:overflow-visible"], ["menuAlign" => ["left" => "md:justify-start", "center" => "md:justify-center", "right" => "md:justify-end"]]);
        // line 13
        yield "
";
        // line 14
        $context["dropdown_menu_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 15
($context["dropdown_menu"] ?? null), "apply", [["menuAlign" => ((        // line 16
array_key_exists("menu_align", $context)) ? (Twig\Extension\CoreExtension::default(($context["menu_align"] ?? null), "center")) : ("center"))]], "method", false, false, true, 15);
        // line 19
        yield "
<div class=\"container mx-auto px-6 pt-6 md:px-12 md:pt-12\">
  <div
    class=\"navbar @container/navbar relative z-[500] container mx-auto flex justify-between gap-x-8 rounded-md bg-white px-4 py-2 md:rounded-2xl md:px-6 md:pt-2 md:pb-2\"
  >
    <div class=\"navbar--logo self-center [&>div]:flex [&>div]:flex-col [&>div]:justify-center\">
      ";
        // line 25
        yield from $this->unwrap()->yieldBlock('logo', $context, $blocks);
        // line 28
        yield "    </div>

    <div
      class=\"navbar--menu fixed inset-0 top-[calc(var(--drupal-displace-offset-top,0px)+var(--gin-toolbar-height,0px)-var(--navbar-scroll-top,0px))] grid shrink grow grid-cols-[1fr] grid-rows-[auto_1fr_auto] flex-col items-stretch justify-start gap-x-6 bg-background pb-8 md:static md:flex md:h-auto md:flex-row md:items-center md:bg-transparent md:pb-0\"
    >
      <div
        class=\"navbar--modal-top relative z-500 col-span-1 col-start-1 row-span-1 row-start-1 container mx-auto flex w-full justify-between p-2 md:hidden\"
      >
        <div
          class=\"navbar--modal-logo flex min-h-11 flex-1 flex-col items-start justify-center md:hidden [&>div]:flex [&>div]:flex-col [&>div]:justify-center\"
        >
          ";
        // line 39
        yield from         $this->unwrap()->yieldBlock("logo", $context, $blocks);
        yield "
        </div>

        <button
          class=\"navbar--hide-menu flex h-11 w-11 flex-0 cursor-pointer items-center justify-center p-2 md:hidden\"
          aria-label=\"";
        // line 44
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Hide menu"));
        yield "\"
        >
          ";
        // line 46
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(Twig\Extension\CoreExtension::include($this->env, $context, "@haven_theme/components/icon/icon.twig", ["icon" => "x", "icon_size" => "medium"]));
        // line 54
        yield "
        </button>
      </div>

      <div
        class=\"navbar--dropdown-menu-wrapper relative col-span-1 col-start-1 row-span-1 row-start-2 container mx-auto min-h-0 w-full flex-1 p-2 px-4 after:pointer-events-none after:absolute after:bottom-0 after:z-3 after:h-24 after:w-full after:bg-linear-to-b after:from-transparent after:to-background after:content-[''] md:p-0 md:after:content-none\"
      >
        <div class=\"";
        // line 61
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["dropdown_menu_classes"] ?? null), "html", null, true);
        yield "\">
          ";
        // line 62
        yield from $this->unwrap()->yieldBlock('navigation', $context, $blocks);
        // line 65
        yield "        </div>
      </div>

      <div
        class=\"navbar--links col-span-1 col-start-1 row-span-1 row-start-3 ml-auto flex w-full flex-initial shrink-0 grow-0 flex-col items-center justify-end gap-3 md:w-auto md:flex-row\"
      >
        ";
        // line 71
        yield from $this->unwrap()->yieldBlock('links', $context, $blocks);
        // line 98
        yield "      </div>
    </div>

    <div class=\"navbar--hamburger-container flex min-h-8 min-w-8 shrink-0 grow-0 items-center justify-center md:hidden\">
      <button class=\"navbar--hamburger flex items-center justify-center\" aria-label=\"";
        // line 102
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Show menu"));
        yield "\">
        ";
        // line 103
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(Twig\Extension\CoreExtension::include($this->env, $context, "@haven_theme/components/icon/icon.twig", ["icon" => "list", "icon_size" => "medium"]));
        // line 111
        yield "
      </button>
    </div>
  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["menu_align"]);        yield from [];
    }

    // line 25
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_logo(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 26
        yield "        ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(Twig\Extension\CoreExtension::include($this->env, $context, "@haven_theme/templates/block/block--system-branding-block.html.twig"));
        yield "
      ";
        yield from [];
    }

    // line 62
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navigation(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 63
        yield "
          ";
        yield from [];
    }

    // line 71
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_links(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 72
        yield "          ";
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(Twig\Extension\CoreExtension::include($this->env, $context, "haven_theme:button", ["variant" => "primary", "label" => t("Button"), "icon" => "arrow-right", "href" => "https://example.com", "size" => "medium"]));
        // line 83
        yield "

          ";
        // line 85
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(Twig\Extension\CoreExtension::include($this->env, $context, "haven_theme:button", ["variant" => "secondary", "label" => t("Another"), "icon" => "arrow-right", "href" => "https://example.com", "size" => "medium"]));
        // line 96
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:navbar";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  189 => 96,  187 => 85,  183 => 83,  180 => 72,  173 => 71,  167 => 63,  160 => 62,  152 => 26,  145 => 25,  134 => 111,  132 => 103,  128 => 102,  122 => 98,  120 => 71,  112 => 65,  110 => 62,  106 => 61,  97 => 54,  95 => 46,  90 => 44,  82 => 39,  69 => 28,  67 => 25,  59 => 19,  57 => 16,  56 => 15,  55 => 14,  52 => 13,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:navbar", "themes/contrib/haven_theme/components/navbar/navbar.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "block" => 25];
        static $filters = ["default" => 16, "t" => 44, "escape" => 61];
        static $functions = ["html_cva" => 2, "include" => 47];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'block'],
                ['default', 't', 'escape'],
                ['html_cva', 'include'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
