<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:hero-side-by-side */
class __TwigTemplate_b9708f1cd20adbd0b20466ca02d7fe6f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'hero_media' => [$this, 'block_hero_media'],
            'hero_content' => [$this, 'block_hero_content'],
            'hero_slot' => [$this, 'block_hero_slot'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--hero-side-by-side"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:hero-side-by-side"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:hero-side-by-side"));
        $context["hero_padding"] = (((($tmp = ((array_key_exists("padding", $context)) ? (Twig\Extension\CoreExtension::default(($context["padding"] ?? null), false)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 2
        yield "
";
        // line 3
        $context["hero"] = Twig\Extra\Html\HtmlExtension::htmlCva(["relative flex h-full"], ["imagePosition" => ["left" => "md:flex-row", "right" => "md:flex-row-reverse"], "heroFlexDirectionMobile" => ["vertical" => "flex-col", "vertical-reverse" => "flex-col-reverse"], "padding" => ["yes" => "p-4 md:p-8", "no" => ""]]);
        // line 22
        yield "
";
        // line 23
        $context["bgd"] = Twig\Extra\Html\HtmlExtension::htmlCva(["absolute inset-0 z-[-1] rounded-lg"], ["background" => ["primary" => "bg-primary-dark text-primary-foreground", "white" => "bg-white text-primary-foreground", "secondary" => "bg-secondary-dark text-secondary-foreground", "accent" => "bg-accent-dark text-accent-foreground"]]);
        // line 36
        yield "
";
        // line 37
        $context["image"] = Twig\Extra\Html\HtmlExtension::htmlCva(["flex-1 overflow-hidden"], ["imageSize" => ["2:1" => "aspect-2/1", "16:9" => "aspect-16/9", "3:2" => "aspect-3/2", "4:3" => "aspect-4/3", "1:1" => "aspect-1/1"], "padding" => ["yes" => "rounded-lg", "no" => ""]], [["padding" => ["no"], "imagePosition" => ["left"], "class" => "md:rounded-l-lg md:rounded-r-none"], ["padding" => ["no"], "imagePosition" => ["right"], "class" => "md:rounded-l-none md:rounded-r-lg"], ["padding" => ["no"], "heroFlexDirectionMobile" => ["vertical"], "class" => "rounded-t-lg"], ["padding" => ["no"], "heroFlexDirectionMobile" => ["vertical-reverse"], "class" => "rounded-b-lg"]]);
        // line 77
        yield "
";
        // line 78
        $context["content"] = Twig\Extra\Html\HtmlExtension::htmlCva(["flex flex-col gap-6"], ["padding" => ["yes" => "py-4 md:px-6", "no" => "p-6 md:p-8"]]);
        // line 89
        yield "
";
        // line 90
        $context["hero_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 91
($context["hero"] ?? null), "apply", [["imagePosition" =>         // line 92
($context["image_position"] ?? null), "heroFlexDirectionMobile" =>         // line 93
($context["hero_flex_direction_mobile"] ?? null), "padding" =>         // line 94
($context["hero_padding"] ?? null)]], "method", false, false, true, 91);
        // line 97
        yield "
";
        // line 98
        $context["bgd_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 99
($context["bgd"] ?? null), "apply", [["background" =>         // line 100
($context["background"] ?? null)]], "method", false, false, true, 99);
        // line 103
        yield "
";
        // line 104
        $context["image_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 105
($context["image"] ?? null), "apply", [["imageSize" =>         // line 106
($context["image_size"] ?? null), "padding" =>         // line 107
($context["hero_padding"] ?? null), "imagePosition" =>         // line 108
($context["image_position"] ?? null), "heroFlexDirectionMobile" =>         // line 109
($context["hero_flex_direction_mobile"] ?? null)]], "method", false, false, true, 105);
        // line 112
        yield "
";
        // line 113
        $context["content_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 114
($context["content"] ?? null), "apply", [["padding" =>         // line 115
($context["hero_padding"] ?? null)]], "method", false, false, true, 114);
        // line 118
        yield "
<section class=\"";
        // line 119
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["hero_classes"] ?? null), "html", null, true);
        yield "\">
  ";
        // line 120
        if (( !Twig\Extension\CoreExtension::testEmpty(($context["background"] ?? null)) && (($context["background"] ?? null) != "None"))) {
            // line 121
            yield "    <div class=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["bgd_classes"] ?? null), "html", null, true);
            yield "\"></div>
  ";
        }
        // line 123
        yield "
  <div class=\"";
        // line 124
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["image_classes"] ?? null), "html", null, true);
        yield "\">
    ";
        // line 125
        yield from $this->unwrap()->yieldBlock('hero_media', $context, $blocks);
        // line 136
        yield "  </div>
  <div class=\"self-center md:flex-1\">
    <div class=\"";
        // line 138
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["content_classes"] ?? null), "html", null, true);
        yield "\">
      ";
        // line 139
        yield from $this->unwrap()->yieldBlock('hero_content', $context, $blocks);
        // line 144
        yield "    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["padding", "image_position", "hero_flex_direction_mobile", "background", "image_size", "media"]);        yield from [];
    }

    // line 125
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_hero_media(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 126
        yield "      ";
        try {
            $_v0 = $this->load("canvas:image", 126);
        } catch (LoaderError $e) {
            // ignore missing template
            $_v0 = null;
        }
        if ($_v0) {
            yield from $_v0->unwrap()->yield(CoreExtension::toArray(["src" => CoreExtension::getAttribute($this->env, $this->source,             // line 127
($context["media"] ?? null), "src", [], "any", false, false, true, 127), "alt" => CoreExtension::getAttribute($this->env, $this->source,             // line 128
($context["media"] ?? null), "alt", [], "any", false, false, true, 128), "class" => "object-cover w-full h-full", "width" => CoreExtension::getAttribute($this->env, $this->source,             // line 130
($context["media"] ?? null), "width", [], "any", false, false, true, 130), "height" => CoreExtension::getAttribute($this->env, $this->source,             // line 131
($context["media"] ?? null), "height", [], "any", false, false, true, 131), "loading" => "eager", "sizes" => "50vw"]));
        }
        // line 135
        yield "    ";
        yield from [];
    }

    // line 139
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_hero_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 140
        yield "        ";
        yield from $this->unwrap()->yieldBlock('hero_slot', $context, $blocks);
        // line 143
        yield "      ";
        yield from [];
    }

    // line 140
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_hero_slot(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 141
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:hero-side-by-side";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  197 => 141,  190 => 140,  185 => 143,  182 => 140,  175 => 139,  170 => 135,  167 => 131,  166 => 130,  165 => 128,  164 => 127,  155 => 126,  148 => 125,  139 => 144,  137 => 139,  133 => 138,  129 => 136,  127 => 125,  123 => 124,  120 => 123,  114 => 121,  112 => 120,  108 => 119,  105 => 118,  103 => 115,  102 => 114,  101 => 113,  98 => 112,  96 => 109,  95 => 108,  94 => 107,  93 => 106,  92 => 105,  91 => 104,  88 => 103,  86 => 100,  85 => 99,  84 => 98,  81 => 97,  79 => 94,  78 => 93,  77 => 92,  76 => 91,  75 => 90,  72 => 89,  70 => 78,  67 => 77,  65 => 37,  62 => 36,  60 => 23,  57 => 22,  55 => 3,  52 => 2,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:hero-side-by-side", "themes/contrib/haven_theme/components/hero-side-by-side/hero-side-by-side.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "if" => 120, "block" => 125, "include" => 126];
        static $filters = ["default" => 1, "escape" => 119];
        static $functions = ["html_cva" => 4];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['default', 'escape'],
                ['html_cva'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
