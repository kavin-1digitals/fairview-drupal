<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/about-wwa/wwa-transparency.twig */
class __TwigTemplate_0f366aa8357e59f37ec14fa1609b363e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"wwa-band\" aria-labelledby=\"wwa-transparency-title\">
  <div class=\"wwa-band__inner\">
    <h2 id=\"wwa-transparency-title\" class=\"wwa-band__title\">";
        // line 9
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Transparency"));
        yield "</h2>
    <div class=\"wwa-cols wwa-cols--3\">
      <div class=\"wwa-col wwa-col--links\">
        <h3 class=\"wwa-col__title\">";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Financial Reporting"));
        yield "</h3>
        <p class=\"wwa-col__desc\">";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("As a nonprofit, we rely on the community to support us in our work, and that means the community has a right to know how we use their donations. Here is our most recent financial information:"));
        yield "</p>
        <ul class=\"wwa-linklist\" role=\"list\">
          <li><a class=\"wwa-arrow-link\" href=\"/about/financials/2024-audited\">";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview’s 2024 audited statement"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
          <li><a class=\"wwa-arrow-link\" href=\"/about/financials/2024-990\">";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("2024 IRS 990 form"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
        </ul>
      </div>
      <div class=\"wwa-col\">
        <h3 class=\"wwa-col__title\">";
        // line 20
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Clinical Outcomes"));
        yield "</h3>
        <p class=\"wwa-col__desc\">
          ";
        // line 22
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("We take pride in our health outcomes, and our patients can take comfort knowing the numbers confirm they are in good hands. You can always view reports on"));
        yield "
          <a href=\"/locations/hospitals\">";
        // line 23
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview Hospitals"));
        yield "</a>,
          <a href=\"/locations/clinics\">";
        // line 24
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview Clinics"));
        yield "</a>
          ";
        // line 25
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("or"));
        yield "
          <a href=\"/locations/bethesda\">";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Bethesda Hospital"));
        yield "</a>.
        </p>
      </div>
      <div class=\"wwa-col\">
        <h3 class=\"wwa-col__title\">";
        // line 30
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Economic Impact"));
        yield "</h3>
        <p class=\"wwa-col__desc\">
          ";
        // line 32
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("When Fairview provides jobs and purchases goods and services, it creates an economic impact that extends beyond our own operations to our local and state businesses and governments. Read about"));
        yield "
          <a href=\"/about/economic-impact\">";
        // line 33
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview’s economic impact"));
        yield "</a>.
        </p>
      </div>
    </div>
  </div>
</section>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/about-wwa/wwa-transparency.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  111 => 33,  107 => 32,  102 => 30,  95 => 26,  91 => 25,  87 => 24,  83 => 23,  79 => 22,  74 => 20,  67 => 16,  63 => 15,  58 => 13,  54 => 12,  48 => 9,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/about-wwa/wwa-transparency.twig", "/var/www/html/web/themes/custom/fairview/components/about-wwa/wwa-transparency.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["t" => 9];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['t'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
