<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:card-icon */
class __TwigTemplate_83069cc169bb1a8ff65af3e4de9a9106 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--card-icon"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:card-icon"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:card-icon"));
        $context["has_url"] = (((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["url"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 2
        yield "
";
        // line 3
        $context["tile"] = Twig\Extra\Html\HtmlExtension::htmlCva(["relative p-6 md:p-8"], ["hasUrl" => ["yes" => "group cursor-pointer hover:scale-103", "no" => ""], "backgroundColor" => ["primary" => "bg-primary/30 text-primary-foreground transition duration-300 hover:bg-primary/20", "secondary" => "bg-secondary/30 text-secondary-foreground transition duration-300 hover:bg-secondary/20", "accent" => "bg-accent/30 text-accent-foreground transition duration-300 hover:bg-accent/20", "muted" => "bg-muted/10 text-muted-foreground transition duration-300 hover:bg-muted/20", "noColor" => "border border-border bg-none text-foreground transition duration-300 hover:text-foreground/70"], "tileSize" => ["square" => "aspect-square", "4:3" => "aspect-4/3", "16:9" => "aspect-16/9", "noSize" => "aspect-none"], "borderRadius" => ["small" => "rounded-sm", "medium" => "rounded-xl md:rounded-2xl", "large" => "rounded-[24px] md:rounded-[32px]", "noRadius" => "rounded-none"], "textColor" => ["primary" => "text-primary", "secondary" => "text-secondary", "accent" => "text-accent", "inverted" => "text-primary-foreground"]]);
        // line 39
        yield "
";
        // line 40
        $context["tile_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 41
($context["tile"] ?? null), "apply", [["hasUrl" =>         // line 42
($context["has_url"] ?? null), "backgroundColor" => ((        // line 43
array_key_exists("background_color", $context)) ? (Twig\Extension\CoreExtension::default(($context["background_color"] ?? null), "noColor")) : ("noColor")), "textColor" => ((        // line 44
array_key_exists("text_color", $context)) ? (Twig\Extension\CoreExtension::default(($context["text_color"] ?? null), "noColor")) : ("noColor")), "tileSize" => ((        // line 45
array_key_exists("tile_size", $context)) ? (Twig\Extension\CoreExtension::default(($context["tile_size"] ?? null), "noSize")) : ("noSize")), "borderRadius" => ((        // line 46
array_key_exists("border_radius", $context)) ? (Twig\Extension\CoreExtension::default(($context["border_radius"] ?? null), "noRadius")) : ("noRadius"))]], "method", false, false, true, 41);
        // line 49
        yield "
";
        // line 50
        $context["icon_container"] = Twig\Extra\Html\HtmlExtension::htmlCva(["flex", "w-full"], ["iconAlign" => ["left" => "justify-start", "center" => "justify-center", "right" => "justify-end"]]);
        // line 62
        yield "
";
        // line 63
        $context["icon_container_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 64
($context["icon_container"] ?? null), "apply", [["iconAlign" => ((        // line 65
array_key_exists("icon_align", $context)) ? (Twig\Extension\CoreExtension::default(($context["icon_align"] ?? null), "center")) : ("center"))]], "method", false, false, true, 64);
        // line 68
        yield "
";
        // line 69
        $context["icon_size_map"] = ["small" => "small", "medium" => "medium", "large" => "large", "extra-large" => "extra-large"];
        // line 75
        yield "
";
        // line 76
        $context["text_container"] = Twig\Extra\Html\HtmlExtension::htmlCva(["w-full", "pt-2"], ["textAlign" => ["left" => "text-start", "center" => "text-center", "right" => "text-end"]]);
        // line 88
        yield "
";
        // line 89
        $context["text_container_classes"] = CoreExtension::getAttribute($this->env, $this->source,         // line 90
($context["text_container"] ?? null), "apply", [["textAlign" => ((        // line 91
array_key_exists("text_align", $context)) ? (Twig\Extension\CoreExtension::default(($context["text_align"] ?? null), "center")) : ("center"))]], "method", false, false, true, 90);
        // line 94
        yield "
<div class=\"";
        // line 95
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["tile_classes"] ?? null), "html", null, true);
        yield "\">
  <div class=\"flex h-full flex-col justify-center\">
    <div class=\"";
        // line 97
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["icon_container_classes"] ?? null), "html", null, true);
        yield "\">
      ";
        // line 98
        if ((($tmp = ($context["icon"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 99
            yield "        ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(Twig\Extension\CoreExtension::include($this->env, $context, "@haven_theme/components/icon/icon.twig", ["icon" =>             // line 103
($context["icon"] ?? null), "icon_size" => ((CoreExtension::getAttribute($this->env, $this->source,             // line 104
($context["icon_size_map"] ?? null), ($context["icon_size"] ?? null), [], "array", true, true, true, 104)) ? (Twig\Extension\CoreExtension::default((($_v0 = ($context["icon_size_map"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess && in_array($_v0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v0[($context["icon_size"] ?? null)] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["icon_size_map"] ?? null), ($context["icon_size"] ?? null), [], "array", false, false, true, 104)), "medium")) : ("medium"))], false));
            // line 108
            yield "
      ";
        }
        // line 110
        yield "    </div>

    <div class=\"";
        // line 112
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["text_container_classes"] ?? null), "html", null, true);
        yield "\">
      ";
        // line 113
        if (( !Twig\Extension\CoreExtension::testEmpty(($context["text"] ?? null)) ||  !Twig\Extension\CoreExtension::testEmpty(($context["description"] ?? null)))) {
            // line 114
            yield "        ";
            if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["url"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 115
                yield "          <a href=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["url"] ?? null), "html", null, true);
                yield "\" class=\"flex w-full flex-col before:absolute before:inset-0 before:content-['']\">
            ";
                // line 116
                if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["text"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 117
                    yield "              <h3>";
                    if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                        if (\array_key_exists("canvas_slot_ids", $context) && \in_array("text", $context["canvas_slot_ids"], TRUE)) {
                            yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "text");
                        } else {
                            yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "text");
                        }
                    }
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["text"] ?? null), "html", null, true);
                    if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                        if (\array_key_exists("canvas_slot_ids", $context) && \in_array("text", $context["canvas_slot_ids"], TRUE)) {
                            yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "text");
                        } else {
                            yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "text");
                        }
                    }
                    yield "</h3>
            ";
                }
                // line 119
                yield "            ";
                if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["description"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 120
                    yield "              <span class=\"mt-3\">";
                    if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                        if (\array_key_exists("canvas_slot_ids", $context) && \in_array("description", $context["canvas_slot_ids"], TRUE)) {
                            yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "description");
                        } else {
                            yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "description");
                        }
                    }
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["description"] ?? null), "html", null, true);
                    if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                        if (\array_key_exists("canvas_slot_ids", $context) && \in_array("description", $context["canvas_slot_ids"], TRUE)) {
                            yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "description");
                        } else {
                            yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "description");
                        }
                    }
                    yield "</span>
            ";
                }
                // line 122
                yield "          </a>
        ";
            } else {
                // line 124
                yield "          <span class=\"flex w-full flex-col before:absolute before:inset-0 before:content-['']\">
            ";
                // line 125
                if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["text"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 126
                    yield "              <h3>";
                    if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                        if (\array_key_exists("canvas_slot_ids", $context) && \in_array("text", $context["canvas_slot_ids"], TRUE)) {
                            yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "text");
                        } else {
                            yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "text");
                        }
                    }
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["text"] ?? null), "html", null, true);
                    if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                        if (\array_key_exists("canvas_slot_ids", $context) && \in_array("text", $context["canvas_slot_ids"], TRUE)) {
                            yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "text");
                        } else {
                            yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "text");
                        }
                    }
                    yield "</h3>
            ";
                }
                // line 128
                yield "            ";
                if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["description"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 129
                    yield "              <span class=\"mt-3\">";
                    if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                        if (\array_key_exists("canvas_slot_ids", $context) && \in_array("description", $context["canvas_slot_ids"], TRUE)) {
                            yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "description");
                        } else {
                            yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "description");
                        }
                    }
                    yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["description"] ?? null), "html", null, true);
                    if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                        if (\array_key_exists("canvas_slot_ids", $context) && \in_array("description", $context["canvas_slot_ids"], TRUE)) {
                            yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "description");
                        } else {
                            yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "description");
                        }
                    }
                    yield "</span>
            ";
                }
                // line 131
                yield "          </span>
        ";
            }
            // line 133
            yield "      ";
        }
        // line 134
        yield "    </div>
  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["url", "background_color", "text_color", "tile_size", "border_radius", "icon_align", "text_align", "icon", "icon_size", "text", "description"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:card-icon";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  239 => 134,  236 => 133,  232 => 131,  212 => 129,  209 => 128,  189 => 126,  187 => 125,  184 => 124,  180 => 122,  160 => 120,  157 => 119,  137 => 117,  135 => 116,  130 => 115,  127 => 114,  125 => 113,  121 => 112,  117 => 110,  113 => 108,  111 => 104,  110 => 103,  108 => 99,  106 => 98,  102 => 97,  97 => 95,  94 => 94,  92 => 91,  91 => 90,  90 => 89,  87 => 88,  85 => 76,  82 => 75,  80 => 69,  77 => 68,  75 => 65,  74 => 64,  73 => 63,  70 => 62,  68 => 50,  65 => 49,  63 => 46,  62 => 45,  61 => 44,  60 => 43,  59 => 42,  58 => 41,  57 => 40,  54 => 39,  52 => 3,  49 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:card-icon", "themes/contrib/haven_theme/components/card-icon/card-icon.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "if" => 98];
        static $filters = ["default" => 43, "escape" => 95];
        static $functions = ["html_cva" => 4, "include" => 100];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if'],
                ['default', 'escape'],
                ['html_cva', 'include'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
