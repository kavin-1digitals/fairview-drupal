<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/about-wwa/wwa-feature-cards.twig */
class __TwigTemplate_c9beabc24b5e372952ebd1c02459fcd3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"wwa-cards\" aria-labelledby=\"wwa-cards-title\">
  <h2 id=\"wwa-cards-title\" class=\"visually-hidden\">";
        // line 8
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Learn more about Fairview"));
        yield "</h2>
  <div class=\"wwa-cards__inner\">
    <ul class=\"wwa-cards__grid\" role=\"list\">
      <li class=\"wwa-cards__cell\">
        <article class=\"wwa-card\">
          <div class=\"wwa-card__media\">
            <img src=\"";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("wwa_img_base", $context)) ? (Twig\Extension\CoreExtension::default(($context["wwa_img_base"] ?? null), "")) : ("")), "html", null, true);
        yield "WhoWeAre-Content-1.avif\" width=\"480\" height=\"320\" alt=\"\" loading=\"lazy\" />
          </div>
          <div class=\"wwa-card__body\">
            <h3 class=\"wwa-card__title\">";
        // line 17
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Our Guiding Principles"));
        yield "</h3>
            <p class=\"wwa-card__desc\">";
        // line 18
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview’s mission, vision, and values are the fundamental beliefs we follow as we build a healthier future."));
        yield "</p>
            <a class=\"wwa-card__link\" href=\"/about/guiding-principles\">";
        // line 19
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Read More"));
        yield " <span class=\"wwa-card__arrow\" aria-hidden=\"true\">→</span></a>
          </div>
        </article>
      </li>
      <li class=\"wwa-cards__cell\">
        <article class=\"wwa-card\">
          <div class=\"wwa-card__media\">
            <img src=\"";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("wwa_img_base", $context)) ? (Twig\Extension\CoreExtension::default(($context["wwa_img_base"] ?? null), "")) : ("")), "html", null, true);
        yield "WhoWeAre-Content2.avif\" width=\"480\" height=\"320\" alt=\"\" loading=\"lazy\" />
          </div>
          <div class=\"wwa-card__body\">
            <h3 class=\"wwa-card__title\">";
        // line 29
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Our Leadership"));
        yield "</h3>
            <p class=\"wwa-card__desc\">";
        // line 30
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview’s leadership team keeps us focused on our long-term goal of changing the future of medicine by making today healthier. Meet our leadership."));
        yield "</p>
            <a class=\"wwa-card__link\" href=\"/about/leadership\">";
        // line 31
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Our Leadership"));
        yield " <span class=\"wwa-card__arrow\" aria-hidden=\"true\">→</span></a>
          </div>
        </article>
      </li>
      <li class=\"wwa-cards__cell\">
        <article class=\"wwa-card\">
          <div class=\"wwa-card__media\">
            <img src=\"";
        // line 38
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("wwa_img_base", $context)) ? (Twig\Extension\CoreExtension::default(($context["wwa_img_base"] ?? null), "")) : ("")), "html", null, true);
        yield "WhoWeAre-Content3.avif\" width=\"480\" height=\"320\" alt=\"\" loading=\"lazy\" />
          </div>
          <div class=\"wwa-card__body\">
            <h3 class=\"wwa-card__title\">";
        // line 41
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Awards and Recognition"));
        yield "</h3>
            <p class=\"wwa-card__desc\">";
        // line 42
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Fairview’s award-winning care is consistently recognized for excellence in clinical quality and enduring positive outcomes. See our successes."));
        yield "</p>
            <a class=\"wwa-card__link\" href=\"/about/awards\">";
        // line 43
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Read More"));
        yield " <span class=\"wwa-card__arrow\" aria-hidden=\"true\">→</span></a>
          </div>
        </article>
      </li>
    </ul>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["wwa_img_base"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/about-wwa/wwa-feature-cards.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  118 => 43,  114 => 42,  110 => 41,  104 => 38,  94 => 31,  90 => 30,  86 => 29,  80 => 26,  70 => 19,  66 => 18,  62 => 17,  56 => 14,  47 => 8,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/about-wwa/wwa-feature-cards.twig", "/var/www/html/web/themes/custom/fairview/components/about-wwa/wwa-feature-cards.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["t" => 8, "escape" => 14, "default" => 14];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['t', 'escape', 'default'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
