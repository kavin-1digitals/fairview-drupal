<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* haven_theme:card-feature */
class __TwigTemplate_cf321045faa7304d072fbc721fc9a9a9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'media' => [$this, 'block_media'],
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\TwigExtension']->attachLibrary("core/components.haven_theme--card-feature"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->addAdditionalContext($context, "haven_theme:card-feature"));
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar($this->extensions['Drupal\Core\Template\ComponentsTwigExtension']->validateProps($context, "haven_theme:card-feature"));
        $context["card_overlay"] = ((array_key_exists("overlay", $context)) ? (Twig\Extension\CoreExtension::default(($context["overlay"] ?? null), "noColor")) : ("noColor"));
        // line 2
        $context["is_clickable"] = (((($tmp =  !Twig\Extension\CoreExtension::testEmpty(($context["url"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"));
        // line 3
        yield "
";
        // line 4
        $context["card"] = Twig\Extra\Html\HtmlExtension::htmlCva(["group @container relative flex aspect-square flex-col gap-8 rounded-sm in-[.views-row]:h-full"], ["clickable" => ["yes" => "transition duration-300 hover:scale-104 hover:shadow-2xl", "no" => ""], "overlay" => ["primary" => "bg-primary", "secondary" => "bg-secondary", "accent" => "bg-accent", "muted" => "bg-muted", "white" => "bg-primary-foreground"]]);
        // line 22
        yield "
";
        // line 23
        $context["card_media"] = Twig\Extra\Html\HtmlExtension::htmlCva("absolute inset-0 mt-auto overflow-hidden rounded-sm", [], [["overlay" => ["primary", "secondary", "accent", "muted", "white"], "class" => "opacity-50"]]);
        // line 35
        yield "
";
        // line 36
        $context["card_image"] = Twig\Extra\Html\HtmlExtension::htmlCva(["h-full w-full object-cover"], ["overlay" => ["noColor" => ""]], [["overlay" => ["primary", "secondary", "accent", "muted", "white"], "class" => "grayscale-50"]]);
        // line 52
        yield "
";
        // line 53
        $context["icon_size_map"] = ["small" => "small", "medium" => "medium", "large" => "large", "extra-large" => "extra-large"];
        // line 59
        yield "
";
        // line 60
        $context["card_content"] = Twig\Extra\Html\HtmlExtension::htmlCva("z-10 flex h-full w-full flex-col items-baseline gap-4 p-4 @min-[350px]:p-6", []);
        // line 61
        yield "
<div
  class=\"";
        // line 63
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,         // line 64
($context["card"] ?? null), "apply", [["clickable" =>         // line 66
($context["is_clickable"] ?? null), "overlay" =>         // line 67
($context["card_overlay"] ?? null)], ((        // line 69
array_key_exists("card_classes", $context)) ? (Twig\Extension\CoreExtension::default(($context["card_classes"] ?? null), "")) : (""))], "method", false, false, true, 64), "html", null, true);
        // line 71
        yield "\"
>
  ";
        // line 73
        if ((($tmp =  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["media"] ?? null), "src", [], "any", false, false, true, 73))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 74
            yield "    <div
      class=\"";
            // line 75
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,             // line 76
($context["card_media"] ?? null), "apply", [["style" =>             // line 77
($context["card_style"] ?? null), "overlay" =>             // line 78
($context["card_overlay"] ?? null)]], "method", false, false, true, 76), "html", null, true);
            // line 80
            yield "\"
    >
      ";
            // line 82
            yield from $this->unwrap()->yieldBlock('media', $context, $blocks);
            // line 94
            yield "      ";
            if ((($context["card_overlay"] ?? null) == "noColor")) {
                // line 95
                yield "        <div class=\"absolute inset-0 h-full w-full bg-gradient-to-b from-transparent to-black/70\"></div>
      ";
            }
            // line 97
            yield "    </div>
  ";
        }
        // line 99
        yield "
  <div
    class=\"";
        // line 101
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source,         // line 102
($context["card_content"] ?? null), "apply", [["style" =>         // line 103
($context["card_style"] ?? null)]], "method", false, false, true, 102), "html", null, true);
        // line 105
        yield "\"
  >
    <header class=\"text-primary-foreground\">
      ";
        // line 108
        if ((($tmp = ($context["icon"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 109
            yield "        ";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(Twig\Extension\CoreExtension::include($this->env, $context, "@haven_theme/components/icon/icon.twig", ["icon" =>             // line 113
($context["icon"] ?? null), "icon_size" => ((CoreExtension::getAttribute($this->env, $this->source,             // line 114
($context["icon_size_map"] ?? null), ($context["icon_size"] ?? null), [], "array", true, true, true, 114)) ? (Twig\Extension\CoreExtension::default((($_v0 = ($context["icon_size_map"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess && in_array($_v0::class, CoreExtension::ARRAY_LIKE_CLASSES, true) ? ($_v0[($context["icon_size"] ?? null)] ?? null) : CoreExtension::getAttribute($this->env, $this->source, ($context["icon_size_map"] ?? null), ($context["icon_size"] ?? null), [], "array", false, false, true, 114)), "medium")) : ("medium"))], false));
            // line 118
            yield "
      ";
        }
        // line 120
        yield "    </header>
    <div class=\"mt-auto flex w-full gap-1 md:gap-2\">
      <h3 class=\"text-2xl leading-none font-semibold text-primary-foreground @min-[250px]:text-3xl @min-[350px]:text-4xl\">
        ";
        // line 123
        if ((($tmp = ($context["is_clickable"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 124
            yield "          <a href=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["url"] ?? null), "html", null, true);
            yield "\" class=\"after:absolute after:inset-0 after:content-['']\">";
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("heading_text", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "heading_text");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "heading_text");
                }
            }
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["heading_text"] ?? null), "html", null, true);
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("heading_text", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "heading_text");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "heading_text");
                }
            }
            yield "</a>
        ";
        } else {
            // line 126
            yield "          ";
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("heading_text", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "start", $context["canvas_uuid"], "heading_text");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "start", $context["canvas_uuid"], "heading_text");
                }
            }
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ($context["heading_text"] ?? null), "html", null, true);
            if ((isset($context["canvas_is_preview"]) && $context["canvas_is_preview"]) && \array_key_exists("canvas_uuid", $context)) {
                if (\array_key_exists("canvas_slot_ids", $context) && \in_array("heading_text", $context["canvas_slot_ids"], TRUE)) {
                    yield \sprintf('<!-- canvas-slot-%s-%s/%s -->', "end", $context["canvas_uuid"], "heading_text");
                } else {
                    yield \sprintf('<!-- canvas-prop-%s-%s/%s -->', "end", $context["canvas_uuid"], "heading_text");
                }
            }
            yield "
        ";
        }
        // line 128
        yield "      </h3>
    </div>
  </div>
</div>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["overlay", "url", "card_classes", "media", "card_style", "icon", "icon_size", "heading_text", "card_orientation"]);        yield from [];
    }

    // line 82
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_media(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 83
        yield "        ";
        try {
            $_v1 = $this->load("canvas:image", 83);
        } catch (LoaderError $e) {
            // ignore missing template
            $_v1 = null;
        }
        if ($_v1) {
            yield from $_v1->unwrap()->yield(CoreExtension::toArray(["src" => CoreExtension::getAttribute($this->env, $this->source,             // line 84
($context["media"] ?? null), "src", [], "any", false, false, true, 84), "alt" => CoreExtension::getAttribute($this->env, $this->source,             // line 85
($context["media"] ?? null), "alt", [], "any", false, false, true, 85), "class" => CoreExtension::getAttribute($this->env, $this->source,             // line 86
($context["card_image"] ?? null), "apply", [["overlay" =>             // line 87
($context["card_overlay"] ?? null)]], "method", false, false, true, 86), "width" => CoreExtension::getAttribute($this->env, $this->source,             // line 89
($context["media"] ?? null), "width", [], "any", false, false, true, 89), "height" => CoreExtension::getAttribute($this->env, $this->source,             // line 90
($context["media"] ?? null), "height", [], "any", false, false, true, 90), "sizes" => (((            // line 91
($context["card_orientation"] ?? null) == "stacked")) ? ("auto, 100vw") : ("50vw"))]));
        }
        // line 93
        yield "      ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "haven_theme:card-feature";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  226 => 93,  223 => 91,  222 => 90,  221 => 89,  220 => 87,  219 => 86,  218 => 85,  217 => 84,  208 => 83,  201 => 82,  191 => 128,  171 => 126,  149 => 124,  147 => 123,  142 => 120,  138 => 118,  136 => 114,  135 => 113,  133 => 109,  131 => 108,  126 => 105,  124 => 103,  123 => 102,  122 => 101,  118 => 99,  114 => 97,  110 => 95,  107 => 94,  105 => 82,  101 => 80,  99 => 78,  98 => 77,  97 => 76,  96 => 75,  93 => 74,  91 => 73,  87 => 71,  85 => 69,  84 => 67,  83 => 66,  82 => 64,  81 => 63,  77 => 61,  75 => 60,  72 => 59,  70 => 53,  67 => 52,  65 => 36,  62 => 35,  60 => 23,  57 => 22,  55 => 4,  52 => 3,  50 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "haven_theme:card-feature", "themes/contrib/haven_theme/components/card-feature/card-feature.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["set" => 1, "if" => 73, "block" => 82, "include" => 83];
        static $filters = ["default" => 1, "escape" => 64];
        static $functions = ["html_cva" => 5, "include" => 110];

        try {
            $this->sandbox->checkSecurity(
                ['set', 'if', 'block', 'include'],
                ['default', 'escape'],
                ['html_cva', 'include'],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
