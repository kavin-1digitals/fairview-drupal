<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/get-care/gc-top-grid.twig */
class __TwigTemplate_5cb5bf90d4590430183ae9c91f8dcf33 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"gc-top\" aria-labelledby=\"gc-top-heading\">
  <h1 id=\"gc-top-heading\" class=\"visually-hidden\">";
        // line 8
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Get care options"));
        yield "</h1>
  <div class=\"gc-top__inner\">
    <ul class=\"gc-grid\">
      ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("gc_grid_cards", $context)) ? (Twig\Extension\CoreExtension::default(($context["gc_grid_cards"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["card"]) {
            // line 12
            yield "        <li class=\"gc-grid__cell\">
          <article class=\"gc-card gc-card--";
            // line 13
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((CoreExtension::getAttribute($this->env, $this->source, $context["card"], "variant", [], "any", true, true, true, 13)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["card"], "variant", [], "any", false, false, true, 13), "cta")) : ("cta")), "html", null, true);
            yield "\">
            <div class=\"gc-card__icon-wrap\" aria-hidden=\"true\">
              ";
            // line 15
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["card"], "icon", [], "any", false, false, true, 15)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 16
                yield "                <img class=\"gc-card__icon\" src=\"";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("gc_icon_base", $context)) ? (Twig\Extension\CoreExtension::default(($context["gc_icon_base"] ?? null), "")) : ("")), "html", null, true);
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["card"], "icon", [], "any", false, false, true, 16), "html", null, true);
                yield "\" width=\"72\" height=\"72\" alt=\"\" loading=\"lazy\" />
              ";
            }
            // line 18
            yield "            </div>
            ";
            // line 19
            if ((CoreExtension::getAttribute($this->env, $this->source, $context["card"], "variant", [], "any", false, false, true, 19) == "arrow")) {
                // line 20
                yield "              <h2 class=\"gc-card__title\">
                <a class=\"gc-card__arrow-link\" href=\"";
                // line 21
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((CoreExtension::getAttribute($this->env, $this->source, $context["card"], "url", [], "any", true, true, true, 21)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["card"], "url", [], "any", false, false, true, 21), "#")) : ("#")), "html", null, true);
                yield "\">
                  <span class=\"gc-card__arrow-text\">";
                // line 22
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["card"], "title", [], "any", false, false, true, 22), "html", null, true);
                yield "</span>
                  <span class=\"gc-card__arrow\" aria-hidden=\"true\">→</span>
                </a>
              </h2>
            ";
            } else {
                // line 27
                yield "              <h2 class=\"gc-card__title gc-card__title--plain\">";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["card"], "title", [], "any", false, false, true, 27), "html", null, true);
                yield "</h2>
            ";
            }
            // line 29
            yield "            <p class=\"gc-card__desc\">";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["card"], "description", [], "any", false, false, true, 29), "html", null, true);
            yield "</p>
            ";
            // line 30
            if (((CoreExtension::getAttribute($this->env, $this->source, $context["card"], "variant", [], "any", false, false, true, 30) == "cta") && CoreExtension::getAttribute($this->env, $this->source, $context["card"], "button_label", [], "any", false, false, true, 30))) {
                // line 31
                yield "              <p class=\"gc-card__actions\">
                <a class=\"gc-card__btn\" href=\"";
                // line 32
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((CoreExtension::getAttribute($this->env, $this->source, $context["card"], "button_url", [], "any", true, true, true, 32)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["card"], "button_url", [], "any", false, false, true, 32), "#")) : ("#")), "html", null, true);
                yield "\">";
                yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["card"], "button_label", [], "any", false, false, true, 32), "html", null, true);
                yield "</a>
              </p>
            ";
            }
            // line 35
            yield "          </article>
        </li>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['card'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 38
        yield "    </ul>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["gc_grid_cards", "gc_icon_base"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/get-care/gc-top-grid.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  126 => 38,  118 => 35,  110 => 32,  107 => 31,  105 => 30,  100 => 29,  94 => 27,  86 => 22,  82 => 21,  79 => 20,  77 => 19,  74 => 18,  67 => 16,  65 => 15,  60 => 13,  57 => 12,  53 => 11,  47 => 8,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/get-care/gc-top-grid.twig", "/var/www/html/web/themes/custom/fairview/components/get-care/gc-top-grid.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 11, "if" => 15];
        static $filters = ["t" => 8, "default" => 11, "escape" => 13];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for', 'if'],
                ['t', 'default', 'escape'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
