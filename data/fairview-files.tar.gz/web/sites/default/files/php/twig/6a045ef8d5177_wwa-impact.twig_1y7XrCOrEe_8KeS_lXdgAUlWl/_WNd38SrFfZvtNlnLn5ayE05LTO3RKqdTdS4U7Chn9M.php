<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/about-wwa/wwa-impact.twig */
class __TwigTemplate_d3c818cf15c1d06c54269ed3870e31ba extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"wwa-band\" aria-labelledby=\"wwa-impact-title\">
  <div class=\"wwa-band__inner\">
    <h2 id=\"wwa-impact-title\" class=\"wwa-band__title\">";
        // line 9
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Our Impact"));
        yield "</h2>
    <div class=\"wwa-cols wwa-cols--3 wwa-cols--impact\">
      <div class=\"wwa-col wwa-col--stat\">
        <h3 class=\"wwa-col__stat\">\$394 million</h3>
        <p class=\"wwa-col__desc\">";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("In support of access to care and services"));
        yield "</p>
      </div>
      <div class=\"wwa-col wwa-col--stat\">
        <h3 class=\"wwa-col__stat\">\$214 million</h3>
        <p class=\"wwa-col__desc\">";
        // line 17
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("For education and workforce development"));
        yield "</p>
      </div>
      <div class=\"wwa-col wwa-col--stat\">
        <h3 class=\"wwa-col__stat\">\$11 million</h3>
        <p class=\"wwa-col__desc\">";
        // line 21
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("For hospital-based research and community programs and services"));
        yield "</p>
      </div>
    </div>
  </div>
</section>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/about-wwa/wwa-impact.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  69 => 21,  62 => 17,  55 => 13,  48 => 9,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/about-wwa/wwa-impact.twig", "/var/www/html/web/themes/custom/fairview/components/about-wwa/wwa-impact.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["t" => 9];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['t'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
