<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/about-wwa/wwa-community.twig */
class __TwigTemplate_9246dd43a2b783a1fcc90f61f37cb632 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"wwa-band wwa-band--muted\" aria-labelledby=\"wwa-community-title\">
  <div class=\"wwa-band__inner\">
    <h2 id=\"wwa-community-title\" class=\"wwa-band__title\">";
        // line 9
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Community Commitment"));
        yield "</h2>
    <div class=\"wwa-cols wwa-cols--2\">
      <div class=\"wwa-col wwa-col--links\">
        <h3 class=\"wwa-col__title\">";
        // line 12
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Improving Healthcare Access"));
        yield "</h3>
        <p class=\"wwa-col__desc\">";
        // line 13
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("We’re not just located in Minnesota’s communities, we’re a part of them. That’s why we devote time and talent to programs that improve access for all members of our community."));
        yield "</p>
        <ul class=\"wwa-linklist\" role=\"list\">
          <li><a class=\"wwa-arrow-link\" href=\"/community/vaccination\">";
        // line 15
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Improving Vaccination Rates"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
          <li><a class=\"wwa-arrow-link\" href=\"/community/health-commons\">";
        // line 16
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Community Health Commons"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
        </ul>
      </div>
      <div class=\"wwa-col wwa-col--links\">
        <h3 class=\"wwa-col__title\">";
        // line 20
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Enhancing Community Health"));
        yield "</h3>
        <p class=\"wwa-col__desc\">";
        // line 21
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Healthcare starts at where we live, work, learn, and play, not in the hospital. We sponsor community health outreach programs because wellness occurs both inside and out of our care facilities."));
        yield "</p>
        <ul class=\"wwa-linklist\" role=\"list\">
          <li><a class=\"wwa-arrow-link\" href=\"/community/commitment\">";
        // line 23
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Our Community Commitment"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
          <li><a class=\"wwa-arrow-link\" href=\"/community/programs\">";
        // line 24
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Community Health Programs"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
          <li><a class=\"wwa-arrow-link\" href=\"/community/supplier-diversity\">";
        // line 25
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Supplier Diversity Program"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
          <li><a class=\"wwa-arrow-link\" href=\"/community/sustainability\">";
        // line 26
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Sustainability"));
        yield " <span aria-hidden=\"true\">→</span></a></li>
        </ul>
      </div>
    </div>
  </div>
</section>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/about-wwa/wwa-community.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  95 => 26,  91 => 25,  87 => 24,  83 => 23,  78 => 21,  74 => 20,  67 => 16,  63 => 15,  58 => 13,  54 => 12,  48 => 9,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/about-wwa/wwa-community.twig", "/var/www/html/web/themes/custom/fairview/components/about-wwa/wwa-community.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = [];
        static $filters = ["t" => 9];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                [],
                ['t'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
