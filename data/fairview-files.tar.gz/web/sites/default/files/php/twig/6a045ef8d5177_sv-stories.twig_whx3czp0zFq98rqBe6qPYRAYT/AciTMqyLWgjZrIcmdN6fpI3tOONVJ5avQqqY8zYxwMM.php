<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @fairview/components/services/sv-stories.twig */
class __TwigTemplate_1b55c88acae493882316ffb31aba08ae extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
        $this->sandbox = $this->extensions[SandboxExtension::class];
        $this->checkSecurity();
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "<section class=\"sv-stories\" data-sv-stories aria-labelledby=\"sv-stories-title\">
  <div class=\"sv-stories__head\">
    <h2 id=\"sv-stories-title\" class=\"sv-stories__title\">";
        // line 9
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((array_key_exists("sv_stories_title", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_stories_title"] ?? null), "")) : ("")), "html", null, true);
        yield "</h2>
    <div class=\"sv-stories__nav\">
      <button type=\"button\" class=\"sv-stories__btn sv-stories__btn--prev\" data-sv-prev aria-label=\"";
        // line 11
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Previous"));
        yield "\">
        <span aria-hidden=\"true\">‹</span>
      </button>
      <button type=\"button\" class=\"sv-stories__btn sv-stories__btn--next\" data-sv-next aria-label=\"";
        // line 14
        yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Next"));
        yield "\">
        <span aria-hidden=\"true\">›</span>
      </button>
    </div>
  </div>
  <div class=\"sv-stories__viewport\">
    <div class=\"sv-stories__track\" data-sv-track>
      ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(((array_key_exists("sv_story_cards", $context)) ? (Twig\Extension\CoreExtension::default(($context["sv_story_cards"] ?? null), [])) : ([])));
        foreach ($context['_seq'] as $context["_key"] => $context["story"]) {
            // line 22
            yield "        <article class=\"sv-story-card\">
          <div class=\"sv-story-card__media\" aria-hidden=\"true\">
            <div class=\"sv-story-card__placeholder\"></div>
          </div>
          <div class=\"sv-story-card__body\">
            <h3 class=\"sv-story-card__title\">";
            // line 27
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["story"], "title", [], "any", false, false, true, 27), "html", null, true);
            yield "</h3>
            <p class=\"sv-story-card__desc\">";
            // line 28
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, CoreExtension::getAttribute($this->env, $this->source, $context["story"], "description", [], "any", false, false, true, 28), "html", null, true);
            yield "</p>
            <a class=\"sv-story-card__arrow\" href=\"";
            // line 29
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->escapeFilter($this->env, ((CoreExtension::getAttribute($this->env, $this->source, $context["story"], "url", [], "any", true, true, true, 29)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["story"], "url", [], "any", false, false, true, 29), "#")) : ("#")), "html", null, true);
            yield "\" aria-label=\"";
            yield $this->extensions['Drupal\Core\Template\TwigExtension']->renderVar(t("Read more"));
            yield "\">
              <span aria-hidden=\"true\">→</span>
            </a>
          </div>
        </article>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['story'], $context['_parent']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        yield "    </div>
  </div>
</section>
";
        $this->env->getExtension('\Drupal\Core\Template\TwigExtension')
            ->checkDeprecations($context, ["sv_stories_title", "sv_story_cards"]);        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@fairview/components/services/sv-stories.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  102 => 35,  88 => 29,  84 => 28,  80 => 27,  73 => 22,  69 => 21,  59 => 14,  53 => 11,  48 => 9,  44 => 7,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@fairview/components/services/sv-stories.twig", "/var/www/html/web/themes/custom/fairview/components/services/sv-stories.twig");
    }
    
    public function checkSecurity()
    {
        static $tags = ["for" => 21];
        static $filters = ["escape" => 9, "default" => 9, "t" => 11];
        static $functions = [];

        try {
            $this->sandbox->checkSecurity(
                ['for'],
                ['escape', 'default', 't'],
                [],
                $this->source
            );
        } catch (SecurityError $e) {
            $e->setSourceContext($this->source);

            if ($e instanceof SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

    }
}
